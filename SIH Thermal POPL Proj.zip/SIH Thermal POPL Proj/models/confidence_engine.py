"""
Uncertainty Quantification & Schedule Confidence Scoring Engine.
Evaluates weather volatility, cloud cover intermittency, prediction intervals,
and physical ramp limit proximity to generate a robust 0-100% confidence score.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

class ConfidenceEngine:
    """Computes uncertainty intervals and operational confidence scores for ramping schedules."""

    @staticmethod
    def evaluate_confidence(
        weather_df: pd.DataFrame,
        net_demand_mw: np.ndarray,
        p_target_mw: np.ndarray,
        p_max: float,
        p_mtl: float,
        ramp_limit_mw_min: float
    ) -> Dict[str, Any]:
        """
        Computes prediction bounds and overall schedule confidence score.
        """
        w_24 = weather_df.head(24)
        clouds = w_24["cloud_cover_pct"].values
        winds = w_24["wind_speed_ms"].values

        # 1. Weather Volatility Penalty (0 - 15 points)
        # Cloud cover standard deviation over 24h
        cloud_std = float(np.std(clouds))
        cloud_penalty = min(15.0, (cloud_std / 30.0) * 15.0)

        # Wind speed variation penalty (0 - 10 points)
        wind_std = float(np.std(winds))
        wind_penalty = min(10.0, (wind_std / 4.0) * 10.0)

        # 2. Ramp Feasibility Margin Penalty (0 - 15 points)
        # Check how close unconstrained ramps are to the physical limit
        dt_mins = 15.0
        required_ramps = np.abs(np.diff(p_target_mw)) / dt_mins
        max_req_ramp = float(np.max(required_ramps)) if len(required_ramps) > 0 else 0.0

        ramp_utilization = max_req_ramp / ramp_limit_mw_min
        if ramp_utilization > 0.90:
            ramp_penalty = min(15.0, (ramp_utilization - 0.90) * 100.0)
        else:
            ramp_penalty = 0.0

        # 3. Low-Load MTL Proximity Penalty (0 - 8 points)
        # How many blocks are operating within 5% of MTL?
        mtl_buffer = p_mtl + 0.05 * (p_max - p_mtl)
        near_mtl_blocks = np.sum(p_target_mw <= mtl_buffer)
        mtl_penalty = min(8.0, (near_mtl_blocks / 96.0) * 12.0)

        # Base confidence is 97% for day-ahead lookahead
        base_confidence = 97.0
        total_penalties = cloud_penalty + wind_penalty + ramp_penalty + mtl_penalty
        overall_confidence_pct = round(max(55.0, base_confidence - total_penalties), 1)

        # Qualitative classification
        if overall_confidence_pct >= 85.0:
            confidence_level = "High Confidence"
            badge_color = "green"
        elif overall_confidence_pct >= 72.0:
            confidence_level = "Moderate Confidence"
            badge_color = "amber"
        else:
            confidence_level = "Low Confidence (High Intermittency)"
            badge_color = "red"

        # Uncertainty bounds (+/- percentage on net demand)
        # Higher cloud variability widens the band
        band_pct = (100.0 - overall_confidence_pct) * 0.20 / 100.0  # ~2% to 8%
        net_demand_upper = net_demand_mw * (1.0 + band_pct)
        net_demand_lower = net_demand_mw * (1.0 - band_pct)

        return {
            "overall_confidence_pct": overall_confidence_pct,
            "confidence_level": confidence_level,
            "badge_color": badge_color,
            "cloud_volatility_std": round(cloud_std, 1),
            "wind_volatility_std": round(wind_std, 2),
            "max_required_ramp_rate": round(max_req_ramp, 2),
            "ramp_limit_utilization_pct": round(ramp_utilization * 100.0, 1),
            "net_demand_upper_bound": net_demand_upper,
            "net_demand_lower_bound": net_demand_lower,
            "band_pct": round(band_pct * 100.0, 1)
        }
