"""
Net Demand and Thermal Headroom Derivation Engine.
Computes regional Net Demand (Gross Demand - RE), duck curve characteristics,
and scales target dispatch and ramping headroom for an individual thermal power plant.
"""

import numpy as np
from typing import Dict, Any, Tuple

class NetDemandEngine:
    """Derives regional net demand and individual thermal plant target dispatch."""

    @staticmethod
    def compute_net_demand(
        gross_demand_mw: np.ndarray,
        solar_gen_mw: np.ndarray,
        wind_gen_mw: np.ndarray
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Net Demand = Gross Demand - (Solar + Wind).
        Computes duck curve belly depth and evening neck ramp steepness.
        """
        re_total_mw = solar_gen_mw + wind_gen_mw
        net_demand_mw = np.maximum(0.0, gross_demand_mw - re_total_mw)

        # 15-min intervals: dt = 0.25 hr
        ramp_15min_mw = np.diff(net_demand_mw)
        # Convert to MW/hr
        ramp_hourly_rate = ramp_15min_mw * 4.0

        max_ramp_up_mw_hr = float(np.max(ramp_hourly_rate))
        max_ramp_down_mw_hr = float(np.min(ramp_hourly_rate))

        # Duck curve metrics
        solar_peak_block = int(np.argmax(solar_gen_mw))
        evening_peak_block = int(np.argmax(net_demand_mw[64:])) + 64 if len(net_demand_mw) >= 64 else 80

        belly_depth_mw = float(gross_demand_mw[solar_peak_block] - net_demand_mw[solar_peak_block])
        evening_neck_ramp_mw = float(net_demand_mw[evening_peak_block] - net_demand_mw[solar_peak_block])

        stats = {
            "min_net_demand_mw": round(float(np.min(net_demand_mw)), 1),
            "max_net_demand_mw": round(float(np.max(net_demand_mw)), 1),
            "avg_net_demand_mw": round(float(np.mean(net_demand_mw)), 1),
            "max_ramp_up_mw_hr": round(max_ramp_up_mw_hr, 1),
            "max_ramp_down_mw_hr": round(max_ramp_down_mw_hr, 1),
            "belly_depth_mw": round(belly_depth_mw, 1),
            "evening_neck_ramp_mw": round(evening_neck_ramp_mw, 1),
            "solar_belly_time": f"{solar_peak_block * 15 // 60:02d}:{(solar_peak_block * 15) % 60:02d}",
            "evening_peak_time": f"{evening_peak_block * 15 // 60:02d}:{(evening_peak_block * 15) % 60:02d}"
        }

        return net_demand_mw, stats

    @staticmethod
    def derive_plant_target_dispatch(
        net_demand_mw: np.ndarray,
        p_max: float,
        p_mtl: float,
        current_dispatch_mw: float = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Derives an individual thermal unit's target dispatch curve P_target[t]
        following the regional net demand modulation between MTL and Pmax.
        Returns (target_dispatch_mw, headroom_down_mw, headroom_up_mw).
        """
        min_net = np.min(net_demand_mw)
        max_net = np.max(net_demand_mw)

        if max_net - min_net > 1e-3:
            norm_net = (net_demand_mw - min_net) / (max_net - min_net)
        else:
            norm_net = np.ones_like(net_demand_mw) * 0.8

        # Target dispatch mapped between P_MTL and P_max
        # Give a small 3% buffer above MTL for baseline flame stability
        p_target = p_mtl + (p_max - p_mtl) * (0.05 + 0.95 * norm_net)

        # If current dispatch is given, smooth first block towards current
        if current_dispatch_mw is not None:
            p_target[0] = 0.5 * current_dispatch_mw + 0.5 * p_target[0]

        headroom_down_mw = np.maximum(0.0, p_target - p_mtl)
        headroom_up_mw = np.maximum(0.0, p_max - p_target)

        return p_target, headroom_down_mw, headroom_up_mw
