"""
Renewable Generation Forecaster (Solar & Wind).
Physical and statistical models driven by weather forecast variables (GHI, cloud cover, temperature, wind speed)
and official CEA 2024 installed capacities for Gujarat, Rajasthan, and Maharashtra.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from data.cea_capacity import get_state_capacity

class RenewableForecaster:
    """Predicts next-24h solar and wind generation profiles in 96 blocks (15-min intervals)."""

    @staticmethod
    def forecast_solar(
        state: str,
        weather_df: pd.DataFrame
    ) -> np.ndarray:
        """
        Calculates 96-block solar generation (MW) from solar irradiance, cloud cover, and ambient temperature.
        """
        cap = get_state_capacity(state)
        solar_installed_mw = cap["solar_mw"]

        # Resample 24 hours of weather data to 96 blocks (interpolate 15-min steps)
        w_24 = weather_df.head(24).copy()
        time_hours = np.linspace(0, 24, 24, endpoint=False)
        time_96 = np.linspace(0, 24, 96, endpoint=False)

        irr_hourly = w_24["solar_irradiance_wm2"].values
        clouds_hourly = w_24["cloud_cover_pct"].values
        temp_hourly = w_24["temperature_c"].values

        # Linear interpolation across 96 blocks
        irr_96 = np.interp(time_96, time_hours, irr_hourly)
        clouds_96 = np.interp(time_96, time_hours, clouds_hourly)
        temp_96 = np.interp(time_96, time_hours, temp_hourly)

        # Standard Test Conditions (STC): 1000 W/m2, 25 deg C
        # Temperature derating coefficient: -0.004 per deg C above 25 deg C
        temp_derate = 1.0 - 0.004 * np.maximum(0.0, temp_96 - 25.0)

        # Cloud attenuation factor (diffuse transmission)
        cloud_factor = 1.0 - (clouds_96 / 100.0) * 0.72

        # Efficiency and AC performance ratio (typically 0.78 for Indian utility-scale solar parks)
        pr = 0.78

        # Solar output: Capacity * (GHI / 1000) * PR * Temp_Derate * Cloud_Factor
        solar_mw = solar_installed_mw * (irr_96 / 1000.0) * pr * temp_derate * cloud_factor
        solar_mw = np.maximum(0.0, solar_mw)

        # Solar cannot generate at night (before 06:00 and after 18:30)
        night_mask = (time_96 < 5.75) | (time_96 > 18.75)
        solar_mw[night_mask] = 0.0

        return solar_mw

    @staticmethod
    def forecast_wind(
        state: str,
        weather_df: pd.DataFrame
    ) -> np.ndarray:
        """
        Calculates 96-block wind generation (MW) using IEC wind turbine power curve.
        """
        cap = get_state_capacity(state)
        wind_installed_mw = cap["wind_mw"]

        w_24 = weather_df.head(24).copy()
        time_hours = np.linspace(0, 24, 24, endpoint=False)
        time_96 = np.linspace(0, 24, 96, endpoint=False)

        wind_hourly = w_24["wind_speed_ms"].values
        wind_96 = np.interp(time_96, time_hours, wind_hourly)

        # Turbine Power Curve parameters
        v_in = 3.0   # Cut-in speed (m/s)
        v_rated = 11.5  # Rated speed (m/s)
        v_out = 25.0  # Cut-out speed (m/s)

        capacity_factor = np.zeros_like(wind_96)
        for i, v in enumerate(wind_96):
            if v < v_in or v >= v_out:
                capacity_factor[i] = 0.0
            elif v_in <= v < v_rated:
                capacity_factor[i] = ((v - v_in) / (v_rated - v_in)) ** 3
            else:
                capacity_factor[i] = 1.0

        # Account for wake losses and grid availability (0.88 factor)
        wind_mw = wind_installed_mw * capacity_factor * 0.88
        return wind_mw

    def forecast_renewables(
        self,
        state: str,
        weather_df: pd.DataFrame
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
        """
        Returns (solar_mw, wind_mw, total_re_mw, summary_metrics).
        """
        solar_mw = self.forecast_solar(state, weather_df)
        wind_mw = self.forecast_wind(state, weather_df)
        total_re_mw = solar_mw + wind_mw

        summary = {
            "peak_solar_mw": round(float(np.max(solar_mw)), 1),
            "peak_wind_mw": round(float(np.max(wind_mw)), 1),
            "peak_total_re_mw": round(float(np.max(total_re_mw)), 1),
            "solar_energy_gwh": round(float(np.sum(solar_mw) * 0.25 / 1000.0), 2),
            "wind_energy_gwh": round(float(np.sum(wind_mw) * 0.25 / 1000.0), 2),
            "total_re_energy_gwh": round(float(np.sum(total_re_mw) * 0.25 / 1000.0), 2)
        }
        return solar_mw, wind_mw, total_re_mw, summary
