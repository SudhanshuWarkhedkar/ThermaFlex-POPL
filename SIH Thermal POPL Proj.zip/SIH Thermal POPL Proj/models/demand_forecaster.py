"""
State-Wise Gross Demand Forecaster.
Trains XGBoost regression models on 2014-2024 Indian state demand and weather records.
Predicts 24-48h gross regional demand and generates 96-block (15-min) dispatch profiles.
"""

import os
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from xgboost import XGBRegressor
from data.grid_loader import GridDataLoader
from data.cea_capacity import get_state_capacity

class DemandForecaster:
    """Predicts gross electricity demand for Gujarat, Rajasthan, and Maharashtra."""

    def __init__(self, data_loader: GridDataLoader = None):
        self.loader = data_loader or GridDataLoader()
        self.models: Dict[str, XGBRegressor] = {}
        self.feature_cols = [
            "dayofweek", "month", "dayofyear",
            "temperature_c", "cloud_cover_pct", "solar_irradiance_wm2",
            "lag_1d_peak", "rolling_7d_peak"
        ]

    def train(self, state: str) -> Dict[str, float]:
        """Trains an XGBoost model on the state's historical dataset."""
        df = self.loader.load_combined_training_data(state)
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values("date").reset_index(drop=True)

        # Feature Engineering
        df["dayofweek"] = df["date"].dt.dayofweek
        df["month"] = df["date"].dt.month
        df["dayofyear"] = df["date"].dt.dayofyear
        df["temperature_c"] = df["2m_temperature_mean"] - 273.15
        df["cloud_cover_pct"] = df["total_cloud_cover_mean"] * 100.0
        # Surface solar radiation is daily accumulated J/m2 -> convert to average W/m2 (div by 86400)
        df["solar_irradiance_wm2"] = df["surface_solar_radiation_downwards_mean"] / 86400.0

        # Lag features
        df["lag_1d_peak"] = df["peak_met_mw"].shift(1)
        df["rolling_7d_peak"] = df["peak_met_mw"].shift(1).rolling(7).mean()

        clean_df = df.dropna().reset_index(drop=True)

        X = clean_df[self.feature_cols]
        y = clean_df["peak_met_mw"]

        # Train-test split (last 365 days for validation)
        split_idx = max(100, len(clean_df) - 365)
        X_train, X_val = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_val = y.iloc[:split_idx], y.iloc[split_idx:]

        model = XGBRegressor(
            n_estimators=80,
            max_depth=5,
            learning_rate=0.08,
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_train, y_train)

        val_preds = model.predict(X_val)
        mae = float(np.mean(np.abs(val_preds - y_val)))
        mape = float(np.mean(np.abs(val_preds - y_val) / y_val) * 100.0)

        self.models[state.lower()] = model
        print(f"[DemandForecaster] {state} trained successfully. Val MAE: {mae:.1f} MW, MAPE: {mape:.2f}%.")
        return {"mae_mw": round(mae, 1), "mape_pct": round(mape, 2), "samples": len(clean_df)}

    def predict_24h_profile(
        self,
        state: str,
        weather_df: pd.DataFrame
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Forecasts 96-block (15-min) gross regional demand (MW) for the next 24 hours.
        """
        st_key = state.lower()
        if st_key not in self.models:
            self.train(state)

        model = self.models[st_key]

        # Use first 24 hours of weather forecast
        w_24 = weather_df.head(24).copy()
        mean_temp = float(w_24["temperature_c"].mean())
        mean_cloud = float(w_24["cloud_cover_pct"].mean())
        mean_solar = float(w_24["solar_irradiance_wm2"].mean())

        target_date = pd.to_datetime(w_24["timestamp"].iloc[0])
        dow = target_date.dayofweek
        month = target_date.month
        doy = target_date.dayofyear

        # Get recent state baseline peak from historical data
        hist_peak = self.loader.load_historical_peak(state)
        recent_peak = float(hist_peak["peak_met_mw"].iloc[-1])
        recent_7d = float(hist_peak["peak_met_mw"].tail(7).mean())

        # Predict daily peak MW
        feat_vec = pd.DataFrame([{
            "dayofweek": dow,
            "month": month,
            "dayofyear": doy,
            "temperature_c": mean_temp,
            "cloud_cover_pct": mean_cloud,
            "solar_irradiance_wm2": mean_solar,
            "lag_1d_peak": recent_peak,
            "rolling_7d_peak": recent_7d
        }])

        pred_peak_mw = float(model.predict(feat_vec)[0])

        # Synthesize 96-block 15-min load shape
        shape_96 = self.loader.get_diurnal_demand_shape(state)
        # Scale shape: minimum demand is around 68-72% of peak demand in Indian states
        min_ratio = 0.70
        demand_96 = pred_peak_mw * (min_ratio + (1.0 - min_ratio) * shape_96)

        metrics = {
            "predicted_peak_mw": round(pred_peak_mw, 1),
            "predicted_min_mw": round(float(np.min(demand_96)), 1),
            "predicted_avg_mw": round(float(np.mean(demand_96)), 1),
            "total_daily_energy_gwh": round(float(np.sum(demand_96) * 0.25 / 1000.0), 2)
        }

        return demand_96, metrics
