"""ML models and equipment health forecasting for thermal ramping."""
