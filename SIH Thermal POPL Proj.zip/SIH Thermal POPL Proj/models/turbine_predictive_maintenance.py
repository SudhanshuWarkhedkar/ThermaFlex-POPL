"""
NASA C-MAPSS Predictive Maintenance Engine for Power Plant Turbines & Boilers.
Implements:
  Step 1: Ingestion of NASA C-MAPSS Turbofan Degradation Dataset (train_FD001, test_FD001, RUL_FD001).
  Step 2: Advanced Feature Engineering:
    - Multi-window rolling average and standard deviation (W=5, 15) of vibration and temperatures.
    - Rate of change (delta / gradient over 5 cycles).
    - Operational cycle count.
    - Domain cross-sensor ratios (temperature vs pressure, temperature vs speed, enthalpy ratio).
  Step 3: Dual Machine Learning Models:
    - Regression Model (XGBoost Regressor): Remaining Useful Life (RUL) in cycles / days.
    - Classification Model (XGBoost Classifier): Failure Risk Probability in next 30 cycles (0-100%).
  Step 4: Multi-Component Plant Unit Simulation (HP Turbine, LP Turbine, BFP, Superheater Header, ID Fan).
  Step 5: Live Streaming Telemetry Feed Generator for real-time dashboard playback.
"""

import os
import zipfile
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple, Optional
from xgboost import XGBRegressor, XGBClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, roc_auc_score, accuracy_score

# Physical Sensor Mappings to Thermal Plant Turbines & Boilers
SENSOR_MAPPING = {
    "s_2": {"name": "LPC Outlet Temp (°C)", "unit": "°C", "normal": (450, 480), "warning": 490, "critical": 505, "scale": 0.8},
    "s_3": {"name": "HPC Outlet Temp (°C)", "unit": "°C", "normal": (580, 620), "warning": 635, "critical": 650, "scale": 0.42},
    "s_4": {"name": "LPT Exhaust Temp (°C)", "unit": "°C", "normal": (680, 720), "warning": 735, "critical": 755, "scale": 0.52},
    "s_7": {"name": "HPC Discharge Pressure (bar)", "unit": "bar", "normal": (35, 38), "warning": 34, "critical": 32, "scale": 0.068},
    "s_8": {"name": "Core Rotor Speed (RPM)", "unit": "RPM", "normal": (2388, 2389), "warning": 2390, "critical": 2393, "scale": 1.0},
    "s_9": {"name": "LP Rotor Speed (RPM)", "unit": "RPM", "normal": (9040, 9070), "warning": 9085, "critical": 9100, "scale": 1.0},
    "s_11": {"name": "Combustor Static Pressure (bar)", "unit": "bar", "normal": (46.8, 47.4), "warning": 47.8, "critical": 48.3, "scale": 1.0},
    "s_12": {"name": "Fuel Flow Ratio", "unit": "ratio", "normal": (520, 523), "warning": 518, "critical": 515, "scale": 1.0},
    "s_15": {"name": "Bearing Vibration (mm/s RMS)", "unit": "mm/s", "normal": (8.35, 8.42), "warning": 8.46, "critical": 8.52, "scale": 1.0},
    "s_20": {"name": "HPT Bleed Coolant Temp (°C)", "unit": "°C", "normal": (38.8, 39.1), "warning": 38.6, "critical": 38.3, "scale": 1.0},
    "s_21": {"name": "LPT Bleed Coolant Temp (°C)", "unit": "°C", "normal": (23.2, 23.4), "warning": 23.1, "critical": 22.9, "scale": 1.0}
}

PLANT_FLEET_COMPONENTS = {
    "Unit 1: HP Turbine Rotor": {
        "unit_id": 34,
        "role": "High-Pressure Turbine Rotor & Bearings",
        "material": "Nickel-based Superalloy IN718",
        "description": "Exposed to extreme main steam temperatures (565°C) and cyclic centrifugal stress."
    },
    "Unit 2: LP Turbine Blades": {
        "unit_id": 100,
        "role": "Low-Pressure Turbine Last-Stage Blades",
        "material": "Titanium Alloy Ti-6Al-4V",
        "description": "Vulnerable to wet steam droplet erosion and high-cycle vibration fatigue."
    },
    "Unit 3: Boiler Feed Pump (BFP)": {
        "unit_id": 1,
        "role": "Multi-Stage High-Pressure Boiler Feed Pump",
        "material": "13Cr Stainless Steel",
        "description": "Supplies feed water at 280 bar; monitors bearing vibration and seal differential pressure."
    },
    "Unit 4: Superheater Steam Header": {
        "unit_id": 49,
        "role": "Superheater & Reheater Outlet Steam Header",
        "material": "P91/P92 Martensitic Alloy",
        "description": "Suffers low-cycle thermal fatigue and creep during rapid MW/min dispatch ramping."
    },
    "Unit 5: ID Fan Bearings": {
        "unit_id": 24,
        "role": "Induced Draft (ID) Flue Gas Fan",
        "material": "Spherical Roller Bearings",
        "description": "Crucial for furnace draft balance; monitored for unbalance vibration and temperature."
    }
}

class TurbinePredictiveMaintenance:
    """End-to-End NASA C-MAPSS Feature Engineering, Dual ML Training & Live Feed Simulator."""

    def __init__(self, base_dir: Optional[str] = None):
        if base_dir is None:
            self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        else:
            self.base_dir = base_dir

        self.zip_path = os.path.join(
            self.base_dir,
            "6. Turbofan Engine Degradation Simulation Data Set",
            "CMAPSSData.zip"
        )

        self.raw_cols = ["unit", "time", "setting_1", "setting_2", "setting_3"] + [f"s_{i}" for i in range(1, 22)]
        self.key_sensors = list(SENSOR_MAPPING.keys())

        # Models
        self.reg_model = XGBRegressor(
            n_estimators=70,
            max_depth=4,
            learning_rate=0.08,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1
        )
        self.clf_model = XGBClassifier(
            n_estimators=70,
            max_depth=4,
            learning_rate=0.08,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1
        )
        self.is_trained = False
        self.train_metrics = {}
        self.test_metrics = {}

        # Cached datasets
        self.train_df: Optional[pd.DataFrame] = None
        self.test_df: Optional[pd.DataFrame] = None
        self.true_rul_df: Optional[pd.DataFrame] = None
        self.feature_columns: List[str] = []

        # Auto-train on initialization
        self.train()

    def _load_data_from_zip(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Reads train_FD001, test_FD001, and RUL_FD001 directly from the zip file."""
        if not os.path.exists(self.zip_path):
            raise FileNotFoundError(f"CMAPSSData.zip not found at: {self.zip_path}")

        with zipfile.ZipFile(self.zip_path, "r") as z:
            with z.open("train_FD001.txt") as f:
                train_df = pd.read_csv(f, sep=r"\s+", header=None, names=self.raw_cols)
            with z.open("test_FD001.txt") as f:
                test_df = pd.read_csv(f, sep=r"\s+", header=None, names=self.raw_cols)
            with z.open("RUL_FD001.txt") as f:
                rul_df = pd.read_csv(f, sep=r"\s+", header=None, names=["true_rul"])
                rul_df["unit"] = np.arange(1, len(rul_df) + 1)

        return train_df, test_df, rul_df

    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 2 Feature Engineering:
          - Rolling mean & std over 5 and 15 cycles
          - Rate of change (delta over 5 cycles)
          - Operational cycle count
          - Domain cross-sensor ratios
        """
        df_out = df.copy()

        # Sort by unit and time
        df_out = df_out.sort_values(["unit", "time"]).reset_index(drop=True)

        feature_cols = []

        # 1. Base key sensors
        for s in self.key_sensors:
            feature_cols.append(s)

        # 2. Rolling statistics (Mean & Std over windows 5 and 15)
        for w in [5, 15]:
            for s in ["s_2", "s_3", "s_4", "s_7", "s_11", "s_15"]:
                col_mean = f"{s}_roll_mean_{w}"
                col_std = f"{s}_roll_std_{w}"
                df_out[col_mean] = df_out.groupby("unit")[s].rolling(w, min_periods=1).mean().reset_index(drop=True)
                df_out[col_std] = df_out.groupby("unit")[s].rolling(w, min_periods=1).std().fillna(0.0).reset_index(drop=True)
                feature_cols.extend([col_mean, col_std])

        # 3. Rate of change (Delta over 5 cycles)
        for s in ["s_2", "s_3", "s_4", "s_15"]:
            col_delta = f"{s}_delta_5"
            df_out[col_delta] = df_out.groupby("unit")[s].diff(5).fillna(0.0)
            feature_cols.append(col_delta)

        # 4. Cycle count
        df_out["cycle_count"] = df_out["time"]
        feature_cols.append("cycle_count")

        # 5. Cross-Sensor Domain Ratios
        # Temperature to Temperature (Turbine to Compressor)
        df_out["ratio_temp_s4_s3"] = df_out["s_4"] / np.maximum(df_out["s_3"], 1e-3)
        # Temperature to Pressure (LPC Temp to HPC Pressure)
        df_out["ratio_temp_press_s2_s7"] = df_out["s_2"] / np.maximum(df_out["s_7"], 1e-3)
        # Temperature to Speed (HPC Temp to Rotor Speed)
        df_out["ratio_temp_speed_s3_s8"] = df_out["s_3"] / np.maximum(df_out["s_8"], 1e-3)
        # Turbine Temp to Combustor Pressure
        df_out["ratio_temp_press_s4_s11"] = df_out["s_4"] / np.maximum(df_out["s_11"], 1e-3)
        # Fuel Flow to Pressure Ratio
        df_out["ratio_fuel_press_s12_s11"] = df_out["s_12"] / np.maximum(df_out["s_11"], 1e-3)

        feature_cols.extend([
            "ratio_temp_s4_s3",
            "ratio_temp_press_s2_s7",
            "ratio_temp_speed_s3_s8",
            "ratio_temp_press_s4_s11",
            "ratio_fuel_press_s12_s11"
        ])

        self.feature_columns = feature_cols
        return df_out

    def train(self) -> Dict[str, Any]:
        """
        Step 3: Fits XGBoost Regressor (RUL) and XGBoost Classifier (Failure Risk Score in 30 cycles).
        Evaluates on test_FD001 benchmark with RUL_FD001 ground truth.
        """
        train_raw, test_raw, true_rul = self._load_data_from_zip()

        # Calculate Training RUL (Piecewise linear target clipped at 125 cycles)
        max_cycle = train_raw.groupby("unit")["time"].max().reset_index().rename(columns={"time": "max_time"})
        train_df = pd.merge(train_raw, max_cycle, on="unit")
        train_df["RUL"] = np.minimum(125.0, train_df["max_time"] - train_df["time"])
        # Classification target: Failure within next 30 cycles
        train_df["fail_in_30"] = (train_df["RUL"] <= 30.0).astype(int)

        # Apply Feature Engineering
        train_feat = self.engineer_features(train_df)
        X_train = train_feat[self.feature_columns]
        y_train_rul = train_feat["RUL"]
        y_train_clf = train_feat["fail_in_30"]

        # 1. Train RUL Regressor
        self.reg_model.fit(X_train, y_train_rul)

        # 2. Train Failure Risk Classifier
        self.clf_model.fit(X_train, y_train_clf)

        # Prepare Test Benchmark Evaluation
        test_feat = self.engineer_features(test_raw)
        # Take the last cycle for each test unit
        test_last = test_feat.groupby("unit").last().reset_index()
        test_merged = pd.merge(test_last, true_rul, on="unit")

        X_test = test_merged[self.feature_columns]
        y_test_rul = test_merged["true_rul"]
        y_test_clf = (y_test_rul <= 30.0).astype(int)

        pred_rul = self.reg_model.predict(X_test)
        pred_prob = self.clf_model.predict_proba(X_test)[:, 1]
        pred_class = (pred_prob >= 0.5).astype(int)

        mae = float(mean_absolute_error(y_test_rul, pred_rul))
        rmse = float(np.sqrt(mean_squared_error(y_test_rul, pred_rul)))
        acc = float(accuracy_score(y_test_clf, pred_class))
        roc = float(roc_auc_score(y_test_clf, pred_prob))

        self.train_df = train_feat
        self.test_df = test_feat
        self.true_rul_df = true_rul
        self.is_trained = True

        self.test_metrics = {
            "rul_mae_cycles": round(mae, 2),
            "rul_rmse_cycles": round(rmse, 2),
            "classification_accuracy": round(acc * 100.0, 1),
            "classification_roc_auc": round(roc, 3),
            "total_train_cycles": len(train_feat),
            "test_units_evaluated": len(test_merged)
        }
        return self.test_metrics

    def predict_component_telemetry(
        self,
        component_name: str,
        cycle_step: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Retrieves real-time telemetry, sensor readings, RUL prediction, and Failure Risk Score
        for a specific plant component at a given cycle.
        """
        if not self.is_trained:
            self.train()

        comp_cfg = PLANT_FLEET_COMPONENTS.get(component_name, list(PLANT_FLEET_COMPONENTS.values())[0])
        unit_id = comp_cfg["unit_id"]

        unit_data = self.test_df[self.test_df["unit"] == unit_id].sort_values("time").reset_index(drop=True)
        max_available_cycles = len(unit_data)

        if cycle_step is None or cycle_step >= max_available_cycles:
            target_idx = max_available_cycles - 1
        else:
            target_idx = max(0, min(cycle_step, max_available_cycles - 1))

        current_row = unit_data.iloc[target_idx]
        current_cycle = int(current_row["time"])

        # Model Inferences
        X_curr = pd.DataFrame([current_row[self.feature_columns]])
        pred_rul = float(self.reg_model.predict(X_curr)[0])
        failure_risk_prob = float(self.clf_model.predict_proba(X_curr)[0, 1])
        failure_risk_pct = round(failure_risk_prob * 100.0, 1)

        # Scale RUL in days (1 cycle = ~0.8 to 1.2 operating days in thermal plant duty)
        estimated_days_to_maintenance = max(1, int(pred_rul * 0.9))

        # Overall Health Index (100% minus failure risk, minimum 15%)
        health_score_pct = round(max(15.0, 100.0 - failure_risk_pct), 1)

        # Sensor readings mapping with status
        sensor_status = {}
        for s_code, meta in SENSOR_MAPPING.items():
            val = float(current_row.get(s_code, 0.0))
            # Format display value
            if s_code in ["s_2", "s_3", "s_4"]:
                # Convert Rankine to Celsius representation
                disp_val = round((val - 459.67) * 5/9, 1)
            elif s_code in ["s_7", "s_11"]:
                # psia to bar
                disp_val = round(val * 0.0689476, 2)
            elif s_code == "s_15":
                disp_val = round(val, 3)
            else:
                disp_val = round(val, 2)

            is_critical = (disp_val >= meta["critical"]) if meta.get("critical", 0) > meta.get("warning", 0) else (disp_val <= meta["critical"])
            is_warning = (disp_val >= meta["warning"]) if meta.get("warning", 0) > meta.get("normal", (0,0))[1] else (disp_val <= meta["warning"])

            sensor_status[s_code] = {
                "name": meta["name"],
                "value": disp_val,
                "unit": meta["unit"],
                "is_warning": is_warning,
                "is_critical": is_critical
            }

        # Alert level & SOP instruction
        if failure_risk_pct >= 75.0:
            alert_level = "CRITICAL"
            alert_color = "#ef4444"
            action_text = f"Immediate overhaul inspection required! Component is at {failure_risk_pct}% failure risk within the next 7-10 days. Schedule borescope inspection."
        elif failure_risk_pct >= 45.0:
            alert_level = "WARNING"
            alert_color = "#f59e0b"
            action_text = f"Moderate thermal creep and vibration detected ({failure_risk_pct}% risk). Limit rapid MW/min ramping; schedule non-destructive testing (NDT) on next shift."
        else:
            alert_level = "NORMAL"
            alert_color = "#10b981"
            action_text = f"Operating smoothly within design thermal limits. Baseline degradation rate nominal ({failure_risk_pct}% risk)."

        # Historical trend slice for plotting (up to current cycle)
        history_df = unit_data.iloc[:target_idx + 1].copy()

        return {
            "component_name": component_name,
            "unit_id": unit_id,
            "role": comp_cfg["role"],
            "material": comp_cfg["material"],
            "description": comp_cfg["description"],
            "current_cycle": current_cycle,
            "max_cycles": max_available_cycles,
            "predicted_rul_cycles": round(pred_rul, 1),
            "estimated_days_to_maintenance": estimated_days_to_maintenance,
            "failure_risk_pct": failure_risk_pct,
            "health_score_pct": health_score_pct,
            "alert_level": alert_level,
            "alert_color": alert_color,
            "action_text": action_text,
            "sensor_readings": sensor_status,
            "history_df": history_df
        }

    def get_fleet_ranked_criticality(self) -> pd.DataFrame:
        """
        Returns a ranked list of all 5 simulated thermal plant components,
        sorted by highest failure risk / lowest RUL ('These units need attention soonest').
        """
        rows = []
        for name in PLANT_FLEET_COMPONENTS.keys():
            res = self.predict_component_telemetry(name, cycle_step=None)
            rows.append({
                "Component": name,
                "Subsystem": res["role"],
                "Failure Risk": f"{res['failure_risk_pct']:.1f}%",
                "risk_raw": res["failure_risk_pct"],
                "RUL (Cycles)": f"{res['predicted_rul_cycles']:.0f}",
                "Est. Maintenance": f"In {res['estimated_days_to_maintenance']} days",
                "Health Score": f"{res['health_score_pct']:.1f}%",
                "Status": res["alert_level"],
                "Action": res["action_text"]
            })

        df_fleet = pd.DataFrame(rows).sort_values("risk_raw", ascending=False).reset_index(drop=True)
        return df_fleet
