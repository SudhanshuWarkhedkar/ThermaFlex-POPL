"""
What-If Scenario Simulator for Grid Stress Testing and Deviation Analysis.
Simulates sudden cloud cover spikes, extreme heatwaves, wind lulls, and equipment constraints.
"""

import copy
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

SCENARIO_CONFIGS = {
    "Baseline (Normal Forecast)": {
        "demand_multiplier": 1.0,
        "solar_multiplier": 1.0,
        "wind_multiplier": 1.0,
        "cloud_offset_pct": 0.0,
        "description": "Standard meteorological and load forecast with expected diurnal patterns."
    },
    "Rapid Cloud Surge / Solar Eclipse (-50% Solar)": {
        "demand_multiplier": 1.0,
        "solar_multiplier": 0.50,
        "wind_multiplier": 1.0,
        "cloud_offset_pct": +45.0,
        "description": "Sudden dense cloud cover or solar eclipse across regional solar parks, causing sudden solar plunge."
    },
    "Extreme Heatwave Surge (+20% Demand)": {
        "demand_multiplier": 1.20,
        "solar_multiplier": 0.95,
        "wind_multiplier": 0.85,
        "cloud_offset_pct": -10.0,
        "description": "Severe heatwave triggers unprecedented agricultural pump and air-conditioning cooling load."
    },
    "Monsoon Wind Lull (-60% Wind Generation)": {
        "demand_multiplier": 1.0,
        "solar_multiplier": 0.90,
        "wind_multiplier": 0.40,
        "cloud_offset_pct": +20.0,
        "description": "Abrupt regional wind drop in wind-heavy corridors requires thermal fleet to supply extra baseload."
    },
    "Restricted Ramp Capability (Pulverizer Derating 10 MW/min)": {
        "demand_multiplier": 1.0,
        "solar_multiplier": 1.0,
        "wind_multiplier": 1.0,
        "cloud_offset_pct": 0.0,
        "forced_ramp_limit_mw_min": 10.0,
        "description": "Plant pulverizer mill maintenance restricts maximum allowable unit ramp rate to 10 MW/min."
    }
}

class ScenarioSimulator:
    """Applies what-if disturbances to weather, demand, and renewable generation."""

    @staticmethod
    def apply_scenario(
        scenario_name: str,
        weather_df: pd.DataFrame,
        gross_demand_mw: np.ndarray,
        solar_gen_mw: np.ndarray,
        wind_gen_mw: np.ndarray
    ) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
        """
        Applies scenario multipliers and returns modified arrays and alert flags.
        """
        cfg = SCENARIO_CONFIGS.get(scenario_name, SCENARIO_CONFIGS["Baseline (Normal Forecast)"])

        mod_weather = weather_df.copy()
        if cfg["cloud_offset_pct"] != 0.0:
            mod_weather["cloud_cover_pct"] = np.clip(
                mod_weather["cloud_cover_pct"] + cfg["cloud_offset_pct"], 0, 100
            )

        mod_demand = gross_demand_mw * cfg["demand_multiplier"]
        mod_solar = solar_gen_mw * cfg["solar_multiplier"]
        mod_wind = wind_gen_mw * cfg["wind_multiplier"]

        # Deviation alert flag
        has_deviation = scenario_name != "Baseline (Normal Forecast)"
        deviation_msg = None

        if "Cloud Surge" in scenario_name:
            deviation_msg = "ALERT: Massive solar generation drop (-50%). Thermal plant must abort ramp-down immediately and sustain higher generation!"
        elif "Heatwave" in scenario_name:
            deviation_msg = "ALERT: Grid demand surged by +20%. Thermal unit required to ramp up to Maximum Continuous Rating (MCR) to avoid load shedding."
        elif "Wind Lull" in scenario_name:
            deviation_msg = "ALERT: Wind deficit detected (-60%). Net demand higher than day-ahead schedule. Spinning reserves dispatched."
        elif "Restricted" in scenario_name:
            deviation_msg = "NOTICE: Plant ramp rate capped at 10 MW/min. Schedule smoothed to prevent boiler tube thermal stress."

        info = {
            "scenario_name": scenario_name,
            "description": cfg["description"],
            "has_deviation": has_deviation,
            "deviation_msg": deviation_msg,
            "forced_ramp_limit": cfg.get("forced_ramp_limit_mw_min")
        }

        return mod_weather, mod_demand, mod_solar, mod_wind, info
