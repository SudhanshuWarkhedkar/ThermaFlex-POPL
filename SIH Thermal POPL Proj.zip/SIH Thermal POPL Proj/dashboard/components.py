"""
Visual Components & Plotly Chart Builders for the Thermal Ramping Predictor Dashboard.
"""

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from typing import Optional
from typing import Dict, Any, List

CONTROL_ROOM_CSS = """
<style>
    /* Metric Cards */
    .metric-card {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border: 1px solid #334155;
        border-radius: 10px;
        padding: 16px 20px;
        color: #f8fafc;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
        margin-bottom: 12px;
    }
    .metric-label {
        font-size: 0.82rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #94a3b8;
        margin-bottom: 6px;
    }
    .metric-value {
        font-size: 1.85rem;
        font-weight: 700;
        color: #38bdf8;
    }
    .metric-sub {
        font-size: 0.78rem;
        color: #cbd5e1;
        margin-top: 4px;
    }

    /* Advisory Cards */
    .advisory-card-info {
        background: rgba(30, 41, 59, 0.7);
        border-left: 4px solid #38bdf8;
        padding: 14px 18px;
        border-radius: 0 8px 8px 0;
        margin-bottom: 12px;
    }
    .advisory-card-warning {
        background: rgba(41, 37, 36, 0.7);
        border-left: 4px solid #f59e0b;
        padding: 14px 18px;
        border-radius: 0 8px 8px 0;
        margin-bottom: 12px;
    }
    .advisory-card-critical {
        background: rgba(69, 10, 10, 0.5);
        border-left: 4px solid #ef4444;
        padding: 14px 18px;
        border-radius: 0 8px 8px 0;
        margin-bottom: 12px;
    }
    .phase-badge {
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        padding: 3px 8px;
        border-radius: 4px;
        display: inline-block;
        margin-bottom: 8px;
    }
</style>
"""

def create_duck_curve_chart(
    time_labels: List[str],
    gross_demand_mw: np.ndarray,
    solar_gen_mw: np.ndarray,
    wind_gen_mw: np.ndarray,
    net_demand_mw: np.ndarray,
    net_upper_mw: np.ndarray,
    net_lower_mw: np.ndarray,
    state: str
) -> go.Figure:
    """Creates the interactive 96-block Duck Curve chart with confidence intervals."""
    fig = go.Figure()

    # 90% Confidence Interval Band for Net Demand
    fig.add_trace(go.Scatter(
        x=time_labels + time_labels[::-1],
        y=np.concatenate([net_upper_mw, net_lower_mw[::-1]]),
        fill="toself",
        fillcolor="rgba(168, 85, 247, 0.15)",
        line=dict(color="rgba(255,255,255,0)"),
        name="Net Demand 90% Confidence Band",
        hoverinfo="skip"
    ))

    # Gross Demand
    fig.add_trace(go.Scatter(
        x=time_labels,
        y=gross_demand_mw,
        name="Gross Grid Demand",
        line=dict(color="#38bdf8", width=2.5),
        mode="lines"
    ))

    # Solar Generation
    fig.add_trace(go.Scatter(
        x=time_labels,
        y=solar_gen_mw,
        name="Solar PV Generation",
        line=dict(color="#facc15", width=2.5),
        mode="lines"
    ))

    # Wind Generation
    fig.add_trace(go.Scatter(
        x=time_labels,
        y=wind_gen_mw,
        name="Wind Generation",
        line=dict(color="#34d399", width=2, dash="dash"),
        mode="lines"
    ))

    # Net Demand (The Duck Curve)
    fig.add_trace(go.Scatter(
        x=time_labels,
        y=net_demand_mw,
        name="Net Demand (Duck Curve)",
        line=dict(color="#c084fc", width=3.5),
        mode="lines"
    ))

    fig.update_layout(
        title=f"<b>24-Hour Regional Load & Duck Curve Analysis ({state})</b>",
        xaxis_title="Time of Day (15-Min Blocks)",
        yaxis_title="Power (MW)",
        template="plotly_dark",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
        height=450
    )
    return fig

def create_ramp_schedule_chart(
    df_schedule: pd.DataFrame,
    p_max: float,
    p_mtl: float,
    unit_name: str
) -> go.Figure:
    """Creates a 2-row subplot: Top: Dispatch trajectory & bounds, Bottom: Ramp rate (MW/min)."""
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.08,
        subplot_titles=[f"<b>Optimized Dispatch vs MTL Limits ({unit_name})</b>", "<b>Ramping Rate (MW/min)</b>"],
        row_heights=[0.70, 0.30]
    )

    times = df_schedule["time"].tolist()

    # Target Dispatch
    fig.add_trace(go.Scatter(
        x=times,
        y=df_schedule["target_mw"],
        name="Target Dispatch (Net Demand Share)",
        line=dict(color="#94a3b8", width=1.5, dash="dot"),
        mode="lines"
    ), row=1, col=1)

    # Optimized Dispatch
    fig.add_trace(go.Scatter(
        x=times,
        y=df_schedule["optimized_mw"],
        name="Optimized Ramping Schedule",
        line=dict(color="#06b6d4", width=3),
        mode="lines"
    ), row=1, col=1)

    # MTL Horizon Line
    fig.add_hline(
        y=p_mtl,
        line_dash="dash",
        line_color="#ef4444",
        annotation_text=f"55% MTL ({p_mtl:.0f} MW)",
        annotation_position="bottom right",
        row=1, col=1
    )

    # Pmax Horizon Line
    fig.add_hline(
        y=p_max,
        line_dash="dash",
        line_color="#10b981",
        annotation_text=f"Pmax Rated ({p_max:.0f} MW)",
        annotation_position="top right",
        row=1, col=1
    )

    # Ramp Rates Bar Plot
    ramp_colors = [
        "#10b981" if r > 0.15 else ("#ef4444" if r < -0.15 else "#64748b")
        for r in df_schedule["ramp_rate_mw_min"]
    ]
    fig.add_trace(go.Bar(
        x=times,
        y=df_schedule["ramp_rate_mw_min"],
        marker_color=ramp_colors,
        name="Ramp Rate (MW/min)",
        showlegend=False
    ), row=2, col=1)

    fig.update_layout(
        template="plotly_dark",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
        height=540
    )
    fig.update_yaxes(title_text="Power (MW)", row=1, col=1)
    fig.update_yaxes(title_text="MW/min", row=2, col=1)
    return fig

def create_maintenance_chart(
    time_labels: List[str],
    stress_profile: np.ndarray,
    ramp_rates: np.ndarray
) -> go.Figure:
    """Plots NASA C-MAPSS based thermal-mechanical stress multiplier across the day."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=time_labels,
        y=stress_profile,
        name="Turbine & Boiler Stress Multiplier",
        line=dict(color="#f97316", width=2.5),
        mode="lines"
    ))

    # Baseline stress line = 1.0 (Steady state baseload)
    fig.add_hline(
        y=1.0,
        line_dash="dot",
        line_color="#64748b",
        annotation_text="Base Baseload Wear (1.0x)",
        annotation_position="bottom right"
    )

    # High Fatigue Warning Line = 1.75x
    fig.add_hline(
        y=1.75,
        line_dash="dash",
        line_color="#ef4444",
        annotation_text="High Fatigue Threshold (1.75x)",
        annotation_position="top right"
    )

    fig.update_layout(
        title="<b>NASA C-MAPSS Equipment Stress & Fatigue Accumulation Index</b>",
        xaxis_title="Time of Day",
        yaxis_title="Relative Stress Multiplier",
        template="plotly_dark",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=50, b=40),
        height=320
    )
    return fig

def create_curtailment_chart(df_curtailment: pd.DataFrame, state: str) -> go.Figure:
    """Plots CEA monthly potential vs actual generation and curtailment percentages."""
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    months = df_curtailment["Month"].tolist()

    # Actual Generation MWh
    fig.add_trace(go.Bar(
        x=months,
        y=df_curtailment["Actual_Total_MWh"] / 1000.0,
        name="Actual RE Generated (GWh)",
        marker_color="#10b981",
        opacity=0.85
    ), secondary_y=False)

    # Curtailed Generation MWh
    fig.add_trace(go.Bar(
        x=months,
        y=df_curtailment["Curtailment_Total_MWh"] / 1000.0,
        name="Curtailment (GWh)",
        marker_color="#ef4444",
        opacity=0.85
    ), secondary_y=False)

    # Curtailment % Line
    fig.add_trace(go.Scatter(
        x=months,
        y=df_curtailment["Curtailment_Total_Pct"],
        name="Curtailment %",
        line=dict(color="#facc15", width=3),
        mode="lines+markers"
    ), secondary_y=True)

    fig.update_layout(
        title=f"<b>Renewable Generation & Curtailment Context ({state}) - Steps 4.1 to 4.5</b>",
        barmode="stack",
        template="plotly_dark",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
        height=380
    )
    fig.update_yaxes(title_text="Generation (GWh)", secondary_y=False)
    fig.update_yaxes(title_text="Curtailment (%)", secondary_y=True, range=[0, max(15, df_curtailment["Curtailment_Total_Pct"].max() + 2)])
    return fig

def create_india_curtailment_map(df_telemetry: pd.DataFrame, selected_state: Optional[str] = None) -> go.Figure:
    """
    Renders an interactive geospatial map of India showing state-wise renewable curtailment.
    Bubble size = Curtailed MW, Color = Severity, Hover = Root-cause diagnostic & financial loss.
    """
    fig = go.Figure()

    # Transmission corridor interconnectors between Top 3 States
    corridor_lines = [
        {"name": "WR-NR Interconnector (Gujarat - Rajasthan, 16,500 MW)", "coords": [(23.2156, 72.6369), (26.9124, 75.7873)], "color": "#f59e0b"},
        {"name": "WR Coastal Corridor (Gujarat - Maharashtra, 14,200 MW)", "coords": [(23.2156, 72.6369), (19.0760, 72.8777)], "color": "#38bdf8"},
        {"name": "NR-WR Inland Corridor (Rajasthan - Maharashtra, 12,500 MW)", "coords": [(26.9124, 75.7873), (19.0760, 72.8777)], "color": "#10b981"},
    ]

    for c in corridor_lines:
        lats = [c["coords"][0][0], c["coords"][1][0]]
        lons = [c["coords"][0][1], c["coords"][1][1]]
        fig.add_trace(go.Scattergeo(
            lat=lats,
            lon=lons,
            mode="lines",
            line=dict(width=3, color=c["color"], dash="dash"),
            name=c["name"],
            hoverinfo="text",
            hovertext=f"<b>Interconnector:</b> {c['name']}<br>High-Voltage Regional Tie Line",
            showlegend=False
        ))

    # Marker sizes scaled by curtailed MW (with floor for 0-curtailment states)
    sizes = [max(16, min(55, np.sqrt(mw) * 0.55 + 14)) if mw > 0 else 16 for mw in df_telemetry["curtailed_mw"]]
    colors = df_telemetry["color"].tolist()

    hover_texts = []
    for _, row in df_telemetry.iterrows():
        txt = (
            f"<b>📍 {row['state']}</b> ({row['region']} Grid)<br>"
            f"⚡ <b>Curtailed:</b> {row['curtailed_mw']:,.1f} MW ({row['curtailment_pct']:.1f}%)<br>"
            f"☀️ <b>Solar Cap:</b> {row['solar_cap_mw']:,.0f} MW | 💨 <b>Wind:</b> {row['wind_cap_mw']:,.0f} MW<br>"
            f"🏭 <b>Thermal Must-Run:</b> {row['thermal_must_run_mw']:,.0f} MW<br>"
            f"📉 <b>Daily Energy Wasted:</b> {row['curtailed_mwh_today']:,.1f} MWh<br>"
            f"💰 <b>Financial Loss:</b> ₹{row['financial_loss_cr']:.2f} Cr / day<br>"
            f"🔌 <b>Corridor ({row['corridor_name']}):</b> {row['corridor_utilization_pct']:.1f}% Load<br>"
            f"🔍 <b>Root Cause:</b> {row['primary_cause']}<br>"
            f"<i>💡 {row['diagnostic_detail']}</i>"
        )
        hover_texts.append(txt)

    # State Bubbles Trace
    fig.add_trace(go.Scattergeo(
        lat=df_telemetry["lat"],
        lon=df_telemetry["lon"],
        mode="markers+text",
        text=df_telemetry["state"],
        textposition="top center",
        textfont=dict(color="#f8fafc", size=12, family="sans-serif"),
        marker=dict(
            size=sizes,
            color=colors,
            opacity=0.92,
            line=dict(width=2, color="#ffffff")
        ),
        hoverinfo="text",
        hovertext=hover_texts,
        name="States Curtailment"
    ))

    # Highlight selected state if provided
    if selected_state and selected_state in df_telemetry["state"].values:
        sub = df_telemetry[df_telemetry["state"] == selected_state].iloc[0]
        fig.add_trace(go.Scattergeo(
            lat=[sub["lat"]],
            lon=[sub["lon"]],
            mode="markers",
            marker=dict(size=sizes[df_telemetry[df_telemetry["state"] == selected_state].index[0]] + 16, color="rgba(56, 189, 248, 0.4)", line=dict(width=3, color="#38bdf8")),
            hoverinfo="skip",
            showlegend=False
        ))

    fig.update_geos(
        visible=True,
        resolution=50,
        showcountries=True,
        countrycolor="#475569",
        showsubunits=True,
        subunitcolor="#64748b",
        showland=True,
        landcolor="#0f172a",
        showocean=True,
        oceancolor="#020617",
        lataxis_range=[16, 30.5],
        lonaxis_range=[67, 81.5],
        center=dict(lat=23.2, lon=74.5),
        projection_type="equirectangular"
    )

    fig.update_layout(
        template="plotly_dark",
        margin=dict(l=0, r=0, t=10, b=10),
        height=520,
        showlegend=False
    )
    return fig

def create_curtailment_ranking_chart(df_telemetry: pd.DataFrame) -> go.Figure:
    """Horizontal bar chart of states ranked by Curtailed MW and MWh wasted."""
    df_sorted = df_telemetry[df_telemetry["curtailed_mw"] > 0].sort_values("curtailed_mw", ascending=True)
    if df_sorted.empty:
        df_sorted = df_telemetry.sort_values("solar_cap_mw", ascending=True).head(5)

    fig = go.Figure(go.Bar(
        x=df_sorted["curtailed_mw"],
        y=df_sorted["state"],
        orientation="h",
        marker=dict(color=df_sorted["color"]),
        text=[f"{val:,.0f} MW ({pct:.1f}%)" for val, pct in zip(df_sorted["curtailed_mw"], df_sorted["curtailment_pct"])],
        textposition="outside",
        hovertext=[f"Wasted: {mwh:,.1f} MWh | Loss: ₹{cr:.2f} Cr" for mwh, cr in zip(df_sorted["curtailed_mwh_today"], df_sorted["financial_loss_cr"])]
    ))

    fig.update_layout(
        title="<b>Renewable Power Curtailed by State (MW)</b>",
        xaxis_title="Curtailed Power (MW)",
        yaxis_title="",
        template="plotly_dark",
        margin=dict(l=20, r=60, t=40, b=40),
        height=380
    )
    return fig

def create_risk_gauge_chart(failure_risk_pct: float, rul_cycles: float, component_name: str) -> go.Figure:
    """Semi-circle gauge displaying Failure Risk % and Remaining Useful Life (RUL)."""
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=failure_risk_pct,
        number={'suffix': "%", 'font': {'size': 38, 'color': '#f8fafc'}},
        title={'text': f"<b>{component_name}</b><br><span style='font-size:0.85em;color:#94a3b8'>Predicted RUL: <b>{rul_cycles:.0f} cycles</b> (~{int(rul_cycles * 0.9)} days)</span>", 'font': {'size': 14}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#94a3b8"},
            'bar': {'color': "#ef4444" if failure_risk_pct >= 75 else ("#f59e0b" if failure_risk_pct >= 45 else "#10b981")},
            'bgcolor': "#1e293b",
            'borderwidth': 1,
            'bordercolor': "#334155",
            'steps': [
                {'range': [0, 45], 'color': "rgba(16, 185, 129, 0.25)"},
                {'range': [45, 75], 'color': "rgba(245, 158, 11, 0.25)"},
                {'range': [75, 100], 'color': "rgba(239, 68, 68, 0.35)"}
            ],
            'threshold': {
                'line': {'color': "#ef4444", 'width': 3},
                'thickness': 0.85,
                'value': 75.0
            }
        }
    ))

    fig.update_layout(
        template="plotly_dark",
        margin=dict(l=25, r=25, t=60, b=20),
        height=240
    )
    return fig

def create_sensor_stream_chart(
    history_df: pd.DataFrame,
    sensor_code: str = "s_4",
    sensor_meta: Optional[Dict[str, Any]] = None
) -> go.Figure:
    """
    Plots sensor telemetry over time/cycles with shaded DANGER ZONE and WARNING threshold lines.
    Simulates real-time sensor trend monitoring.
    """
    if sensor_meta is None:
        sensor_meta = SENSOR_MAPPING.get(sensor_code, {"name": sensor_code, "unit": "", "warning": 735, "critical": 755})

    fig = go.Figure()

    cycles = history_df["time"].tolist()
    raw_vals = history_df[sensor_code].values

    # Scale values to physical units if needed
    if sensor_code in ["s_2", "s_3", "s_4"]:
        vals = (raw_vals - 459.67) * 5/9
    elif sensor_code in ["s_7", "s_11"]:
        vals = raw_vals * 0.0689476
    else:
        vals = raw_vals

    warn_val = sensor_meta.get("warning", np.max(vals) * 0.95)
    crit_val = sensor_meta.get("critical", np.max(vals) * 1.05)
    max_plot_y = max(float(np.max(vals)) * 1.08, crit_val * 1.05)

    # Shaded Danger Zone rectangle
    fig.add_hrect(
        y0=crit_val, y1=max_plot_y,
        fillcolor="rgba(239, 68, 68, 0.18)",
        line_width=0,
        annotation_text="🚨 CRITICAL DANGER ZONE",
        annotation_position="top left",
        annotation_font=dict(color="#ef4444", size=10)
    )

    # Warning line
    fig.add_hline(
        y=warn_val,
        line_dash="dash",
        line_color="#f59e0b",
        annotation_text=f"Warning ({warn_val:.1f} {sensor_meta['unit']})",
        annotation_position="bottom left",
        annotation_font=dict(color="#f59e0b", size=10)
    )

    # Sensor Trace
    fig.add_trace(go.Scatter(
        x=cycles,
        y=vals,
        mode="lines+markers",
        line=dict(color="#38bdf8", width=2.5),
        marker=dict(size=4, color="#38bdf8"),
        name=sensor_meta["name"]
    ))

    # Highlight current/latest point
    if len(cycles) > 0:
        latest_x = cycles[-1]
        latest_y = vals[-1]
        status_dot_color = "#ef4444" if latest_y >= crit_val else ("#f59e0b" if latest_y >= warn_val else "#10b981")
        fig.add_trace(go.Scatter(
            x=[latest_x],
            y=[latest_y],
            mode="markers",
            marker=dict(size=12, color=status_dot_color, line=dict(width=2, color="#ffffff")),
            name="Current Reading",
            showlegend=False
        ))

    fig.update_layout(
        title=f"<b>Live Sensor Telemetry: {sensor_meta['name']}</b>",
        xaxis_title="Operational Wear Cycles (Elapsed)",
        yaxis_title=f"{sensor_meta['name']}",
        template="plotly_dark",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=50, b=40),
        height=320
    )
    return fig
