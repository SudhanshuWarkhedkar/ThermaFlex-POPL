"""Streamlit dashboard and visual components for Thermal Ramping Predictor."""
