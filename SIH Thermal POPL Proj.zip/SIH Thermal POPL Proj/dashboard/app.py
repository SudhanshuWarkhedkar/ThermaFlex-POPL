"""
ThermalFlex AI — Control Room Dispatch Cockpit
Smart India Hackathon 2026 | Team NextGen-Grid (RE04)
Professional dark-theme operational dashboard
"""

import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time

# ──────────────────────────────────────────────────────────────
# Page config — must be first Streamlit call
# ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ThermalFlex AI | Control Room",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────────────────────
# Professional dark CSS
# ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Global */
    .stApp {
        background-color: #0B0F14;
        color: #E8EAED;
    }
    header[data-testid="stHeader"] {
        background: rgba(11,15,20,0.95);
        border-bottom: 1px solid #1E2630;
    }
    /* Sidebar */
    section[data-testid="stSidebar"] {
        background-color: #0F1419 !important;
        border-right: 1px solid #1E2630;
    }
    section[data-testid="stSidebar"] * {
        color: #C9D1D9 !important;
    }
    /* KPI cards */
    .kpi-card {
        background: linear-gradient(145deg, #141A22 0%, #0F1419 100%);
        border: 1px solid #1E2630;
        border-radius: 10px;
        padding: 16px 18px;
        height: 100%;
        transition: border-color 0.2s;
    }
    .kpi-card:hover {
        border-color: #2A6AF5;
    }
    .kpi-label {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #8B949E;
        margin-bottom: 6px;
    }
    .kpi-value {
        font-size: 26px;
        font-weight: 700;
        color: #F0F3F6;
        line-height: 1.1;
    }
    .kpi-sub {
        font-size: 12px;
        color: #6E7681;
        margin-top: 4px;
    }
    .kpi-accent-blue { border-left: 3px solid #2A6AF5; }
    .kpi-accent-cyan { border-left: 3px solid #00C2D1; }
    .kpi-accent-amber { border-left: 3px solid #F5A623; }
    .kpi-accent-green { border-left: 3px solid #3FB950; }
    .kpi-accent-purple { border-left: 3px solid #A371F7; }

    /* Status bar */
    .status-bar {
        background: #0F1419;
        border-top: 1px solid #1E2630;
        padding: 8px 16px;
        font-size: 12px;
        color: #8B949E;
        display: flex;
        justify-content: space-between;
        margin-top: 12px;
        border-radius: 6px;
    }
    .status-ok { color: #3FB950; }
    .status-warn { color: #F5A623; }

    /* Section headers */
    .section-title {
        font-size: 13px;
        font-weight: 600;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #8B949E;
        margin: 18px 0 8px 0;
    }

    /* What-if strip */
    .whatif-strip {
        background: linear-gradient(90deg, #0D1F17 0%, #0F1419 100%);
        border: 1px solid #1B3A2A;
        border-radius: 8px;
        padding: 12px 18px;
        margin: 8px 0 16px 0;
        display: flex;
        gap: 32px;
        align-items: center;
        font-size: 13px;
    }
    .whatif-item strong {
        color: #3FB950;
        font-size: 15px;
    }

    /* Hide Streamlit chrome noise */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    .stDeployButton {display: none;}
</style>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────────────────────
# Synthetic but realistic data (matches screenshot values)
# ──────────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def generate_dispatch_data(mtl_pct: float = 55.0, rated_mw: float = 800.0):
    """96 × 15-min blocks for one operational day."""
    n = 96
    t = np.arange(n)
    hours = t * 0.25

    # Net demand (duck curve) — Gujarat-like profile
    base = 420 + 80 * np.sin((hours - 6) * np.pi / 12)
    solar_dip = -160 * np.exp(-0.5 * ((hours - 13) / 3.2) ** 2)
    evening_peak = 90 * np.exp(-0.5 * ((hours - 19.5) / 2.0) ** 2)
    net_demand = base + solar_dip + evening_peak + np.random.normal(0, 6, n)
    net_demand = np.clip(net_demand, 280, 620)

    # Gross demand (higher)
    gross = net_demand + 40 + 20 * np.sin(hours * np.pi / 12)

    # RE generation
    solar = 220 * np.exp(-0.5 * ((hours - 12.5) / 3.5) ** 2)
    wind = 45 + 25 * np.sin((hours + 2) * np.pi / 10) + np.random.normal(0, 4, n)
    wind = np.clip(wind, 15, 90)

    # Confidence band around net demand
    conf_hi = net_demand + 18 + 8 * np.sin(hours / 3)
    conf_lo = net_demand - 14 - 6 * np.sin(hours / 4)

    # Optimised thermal dispatch (respects MTL)
    mtl_mw = rated_mw * (mtl_pct / 100.0)
    thermal = np.clip(net_demand - solar * 0.65 - wind * 0.4 + 30, mtl_mw, rated_mw * 0.95)
    # Smooth ramps
    for _ in range(3):
        thermal = 0.7 * thermal + 0.15 * np.roll(thermal, 1) + 0.15 * np.roll(thermal, -1)
    thermal = np.clip(thermal, mtl_mw, rated_mw)

    # Target (slightly higher than optimised for illustration)
    target = thermal + 12 + 8 * np.sin(hours * np.pi / 8)
    target = np.clip(target, mtl_mw, rated_mw)

    # Ramp rate (MW per 15-min block) for bar chart
    ramp = np.diff(thermal, prepend=thermal[0])
    ramp_mw_per_min = ramp / 15.0

    df = pd.DataFrame({
        "block": t,
        "hour": hours,
        "time_label": [f"{int(h):02d}:{int((h % 1) * 60):02d}" for h in hours],
        "net_demand": net_demand,
        "gross_demand": gross,
        "solar": solar,
        "wind": wind,
        "conf_hi": conf_hi,
        "conf_lo": conf_lo,
        "thermal_opt": thermal,
        "target": target,
        "ramp_mw_min": ramp_mw_per_min,
        "mtl_line": mtl_mw,
    })
    return df


def compute_kpis(df: pd.DataFrame, rated_mw: float, mtl_pct: float):
    current_dispatch = float(df["thermal_opt"].iloc[56])  # ~14:00
    headroom = current_dispatch - (rated_mw * mtl_pct / 100)
    peak_ramp = float(np.max(np.abs(df["ramp_mw_min"])))
    duck_neck = float(np.max(df["gross_demand"]) - np.min(df["net_demand"]))
    return {
        "current_dispatch": round(current_dispatch, 0),
        "headroom": round(headroom, 0),
        "peak_ramp": round(peak_ramp, 2),
        "duck_neck": round(duck_neck, 0),
        "cmapss_health": 98.5,
        "confidence": 81.3,
    }


# ──────────────────────────────────────────────────────────────
# Sidebar — clean operational controls
# ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚡ ThermalFlex AI")
    st.caption("Grid Flexibility & Plant Intelligence")
    st.markdown("---")

    st.markdown("**Target State / Context**")
    active_state = st.selectbox("Active State", ["Gujarat", "Rajasthan", "Maharashtra"], index=0)

    st.markdown("**CEA 2024 Capacity Profile**")
    st.markdown(
        f"""
        <div style="font-size:12px;line-height:1.6;color:#8B949E">
        • Solar&nbsp;&nbsp;&nbsp; 11,265 MW<br>
        • Wind&nbsp;&nbsp;&nbsp; 11,400 MW<br>
        • Thermal&nbsp; 24,406 MW<br>
        • Grid Region: WR
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.markdown("---")

    st.markdown("**Plant Unit Constraints**")
    unit_preset = st.selectbox("Unit Preset", ["800 MW Supercritical", "660 MW Subcritical", "500 MW"], index=0)
    rated_capacity = st.number_input("Rated Capacity / Proxy (MW)", min_value=200.0, max_value=1000.0, value=800.0, step=10.0)
    min_mtl_pct = st.slider("Minimum Technical Load MTL (%)", min_value=40.0, max_value=60.0, value=55.0, step=1.0)
    max_ramp = st.number_input("Max Ramp Rate Limit (MW/min)", min_value=1.0, max_value=30.0, value=10.0, step=0.5)
    current_load = st.number_input("Current Load (MW)", min_value=200.0, max_value=rated_capacity, value=581.0, step=5.0)

    st.markdown("---")
    st.markdown("**Grid Disturbance Scenario**")
    scenario = st.selectbox("Simulate Event", ["Baseline (None)", "Sudden Cloud Cover", "Wind Drop 30%", "Evening Peak Surge"])

    st.markdown("---")
    if st.button("🔄 Recalculate Dispatch", use_container_width=True, type="primary"):
        st.cache_data.clear()
        st.rerun()

    st.caption("ThermalFlex AI · Built for Smart India Hackathon & Thermal PSP · CEA 2024 Technical Standards")

# ──────────────────────────────────────────────────────────────
# Main content
# ──────────────────────────────────────────────────────────────
# Header
col_h1, col_h2 = st.columns([4, 1])
with col_h1:
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:4px">
            <span style="font-size:22px;font-weight:700;color:#F0F3F6">⚡ AI-Based Flexible Ramping Predictor</span>
        </div>
        <div style="font-size:12px;color:#8B949E">
            Control Room Dispatch Cockpit &nbsp;|&nbsp; State: <b style="color:#C9D1D9">{active_state}</b>
            &nbsp;|&nbsp; Weather Feed: Open-Meteo Live API
            &nbsp;|&nbsp; Timestamp: {datetime.now().strftime("%Y-%m-%d %H:%M IST")}
        </div>
        """,
        unsafe_allow_html=True,
    )
with col_h2:
    st.markdown(
        f"""
        <div class="kpi-card kpi-accent-purple" style="text-align:center;padding:10px">
            <div class="kpi-label">Model Confidence</div>
            <div class="kpi-value" style="font-size:22px">81.3%</div>
            <div class="kpi-sub">Moderate Confidence</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown("")  # spacer

# Generate data
df = generate_dispatch_data(mtl_pct=min_mtl_pct, rated_mw=rated_capacity)
kpis = compute_kpis(df, rated_capacity, min_mtl_pct)

# KPI row
k1, k2, k3, k4, k5 = st.columns(5)
with k1:
    st.markdown(
        f"""
        <div class="kpi-card kpi-accent-blue">
            <div class="kpi-label">Current Unit Dispatch</div>
            <div class="kpi-value">{kpis['current_dispatch']:.0f} <span style="font-size:14px;color:#8B949E">MW</span></div>
            <div class="kpi-sub">Operating at {kpis['current_dispatch']/rated_capacity*100:.1f}% MCR</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
with k2:
    st.markdown(
        f"""
        <div class="kpi-card kpi-accent-cyan">
            <div class="kpi-label">Headroom to {min_mtl_pct:.0f}% MTL</div>
            <div class="kpi-value">{kpis['headroom']:.0f} <span style="font-size:14px;color:#8B949E">MW</span></div>
            <div class="kpi-sub">Down ramp absorption margin</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
with k3:
    st.markdown(
        f"""
        <div class="kpi-card kpi-accent-amber">
            <div class="kpi-label">Peak Ramp Rate</div>
            <div class="kpi-value">{kpis['peak_ramp']:.2f} <span style="font-size:14px;color:#8B949E">MW/min</span></div>
            <div class="kpi-sub">Governor limit: {max_ramp:.1f} MW/min</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
with k4:
    st.markdown(
        f"""
        <div class="kpi-card kpi-accent-blue">
            <div class="kpi-label">Duck Neck Surge</div>
            <div class="kpi-value">{kpis['duck_neck']:,.0f} <span style="font-size:14px;color:#8B949E">MW</span></div>
            <div class="kpi-sub">Net load range at sunset</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
with k5:
    st.markdown(
        f"""
        <div class="kpi-card kpi-accent-green">
            <div class="kpi-label">NASA C-MAPSS Health</div>
            <div class="kpi-value">{kpis['cmapss_health']:.1f}%</div>
            <div class="kpi-sub">Optimal · RUL within bounds</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown("")  # spacer

# What-if value strip (directly links to PDF value proposition)
mtl_40_extra = (55 - 40) / 100 * rated_capacity
est_mwh = mtl_40_extra * 6.5  # rough midday hours
est_cr = est_mwh * 3.2 / 100  # illustrative ₹/kWh
st.markdown(
    f"""
    <div class="whatif-strip">
        <span style="color:#8B949E;font-weight:600;letter-spacing:0.05em;font-size:11px">WHAT-IF · 40% MTL</span>
        <div class="whatif-item">Extra headroom <strong>+{mtl_40_extra:.0f} MW</strong></div>
        <div class="whatif-item">RE absorbed today <strong>~{est_mwh:,.0f} MWh</strong></div>
        <div class="whatif-item">Est. daily value <strong>₹{est_cr:.1f} Cr</strong></div>
        <div class="whatif-item">EOH impact <strong>+2.4 h</strong></div>
    </div>
    """,
    unsafe_allow_html=True,
)

# Tabs for charts
tab1, tab2, tab3 = st.tabs(["📊 Dispatch & Duck Curve", "⚙️ Shift Advisories", "📋 96-Block Schedule"])

with tab1:
    # ── Top chart: Net Demand + RE + Confidence ──
    fig1 = go.Figure()

    # Confidence band
    fig1.add_trace(go.Scatter(
        x=df["hour"], y=df["conf_hi"],
        mode="lines", line=dict(width=0),
        showlegend=False, hoverinfo="skip",
    ))
    fig1.add_trace(go.Scatter(
        x=df["hour"], y=df["conf_lo"],
        mode="lines", line=dict(width=0),
        fill="tonexty", fillcolor="rgba(163,113,247,0.12)",
        name="Net Demand 95% Confidence Band",
        hoverinfo="skip",
    ))

    fig1.add_trace(go.Scatter(
        x=df["hour"], y=df["gross_demand"],
        mode="lines", name="Gross Grid Demand",
        line=dict(color="#6E7681", width=1.5, dash="dot"),
    ))
    fig1.add_trace(go.Scatter(
        x=df["hour"], y=df["net_demand"],
        mode="lines", name="Net Demand (Duck Curve)",
        line=dict(color="#A371F7", width=2.5),
    ))
    fig1.add_trace(go.Scatter(
        x=df["hour"], y=df["solar"],
        mode="lines", name="Solar PV Generation",
        line=dict(color="#F5A623", width=1.8),
    ))
    fig1.add_trace(go.Scatter(
        x=df["hour"], y=df["wind"],
        mode="lines", name="Wind Generation",
        line=dict(color="#00C2D1", width=1.5),
    ))

    # Now marker (~14:00)
    now_h = 14.0
    fig1.add_vline(x=now_h, line_width=1, line_dash="dash", line_color="#3FB950",
                   annotation_text="Now", annotation_position="top", annotation_font_color="#3FB950")

    fig1.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#0F1419",
        height=320,
        margin=dict(l=50, r=20, t=30, b=40),
        legend=dict(
            orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0,
            font=dict(size=11, color="#8B949E"),
            bgcolor="rgba(0,0,0,0)",
        ),
        xaxis=dict(
            title="Time of Day (15-Min Blocks)",
            gridcolor="#1E2630", zeroline=False,
            tickvals=list(range(0, 25, 3)),
            ticktext=[f"{h:02d}:00" for h in range(0, 25, 3)],
            color="#8B949E",
        ),
        yaxis=dict(
            title="Power (MW)",
            gridcolor="#1E2630", zeroline=False,
            color="#8B949E",
        ),
        hovermode="x unified",
    )
    st.plotly_chart(fig1, use_container_width=True)


    # ── Bottom chart: Optimised Dispatch vs MTL ──
    fig2 = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        row_heights=[0.72, 0.28],
        vertical_spacing=0.04,
    )

    # Dispatch lines
    fig2.add_trace(go.Scatter(
        x=df["hour"], y=df["target"],
        mode="lines", name="Target Dispatch (Net Demand Share)",
        line=dict(color="#6E7681", width=1.5, dash="dash"),
    ), row=1, col=1)
    fig2.add_trace(go.Scatter(
        x=df["hour"], y=df["thermal_opt"],
        mode="lines", name="Optimised Ramping Schedule",
        line=dict(color="#2A6AF5", width=2.8),
    ), row=1, col=1)

    # MTL line
    fig2.add_hline(
        y=rated_capacity * min_mtl_pct / 100,
        line_width=1.5, line_dash="dot", line_color="#F85149",
        annotation_text=f"{min_mtl_pct:.0f}% MTL",
        annotation_position="right",
        annotation_font_color="#F85149",
        row=1, col=1,
    )

    # Ramp bars
    colors = ["#3FB950" if v >= 0 else "#F85149" for v in df["ramp_mw_min"]]
    fig2.add_trace(go.Bar(
        x=df["hour"], y=df["ramp_mw_min"],
        name="Ramp Rate (MW/min)",
        marker_color=colors,
        opacity=0.85,
        showlegend=True,
    ), row=2, col=1)

    fig2.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#0F1419",
        height=380,
        margin=dict(l=50, r=20, t=40, b=40),
        legend=dict(
            orientation="h", yanchor="bottom", y=1.08, xanchor="left", x=0,
            font=dict(size=11, color="#8B949E"),
            bgcolor="rgba(0,0,0,0)",
        ),
        hovermode="x unified",
        title=dict(
            text=f"Optimised Dispatch vs MTL Limits  ({active_state} Thermal Unit 1)",
            font=dict(size=13, color="#8B949E"),
            x=0.01, xanchor="left",
        ),
    )
    fig2.update_xaxes(
        gridcolor="#1E2630", color="#8B949E",
        tickvals=list(range(0, 25, 3)),
        ticktext=[f"{h:02d}:00" for h in range(0, 25, 3)],
        row=2, col=1,
    )
    fig2.update_yaxes(title_text="Power (MW)", gridcolor="#1E2630", color="#8B949E", row=1, col=1)
    fig2.update_yaxes(title_text="MW/min", gridcolor="#1E2630", color="#8B949E", row=2, col=1)

    st.plotly_chart(fig2, use_container_width=True)

with tab2:
    st.markdown("##### Shift Handover Advisories — Next 4 Hours (15-min SOPs)")
    # Simple advisory table
    now_block = 56
    adv_df = df.iloc[now_block:now_block + 16][["time_label", "thermal_opt", "ramp_mw_min", "mtl_line"]].copy()
    adv_df.columns = ["Time", "Setpoint (MW)", "Ramp (MW/min)", "MTL Floor (MW)"]
    adv_df["Setpoint (MW)"] = adv_df["Setpoint (MW)"].round(0).astype(int)
    adv_df["Ramp (MW/min)"] = adv_df["Ramp (MW/min)"].round(2)
    adv_df["MTL Floor (MW)"] = adv_df["MTL Floor (MW)"].round(0).astype(int)
    adv_df["Action"] = adv_df["Ramp (MW/min)"].apply(
        lambda r: "Hold" if abs(r) < 0.3 else ("Ramp Up" if r > 0 else "Ramp Down")
    )
    st.dataframe(adv_df, use_container_width=True, hide_index=True, height=420)

    st.info("All setpoints respect governor limits and EOH fatigue bounds. Export via PDF report for shift handover.")

with tab3:
    st.markdown("##### Full 96-Block Optimised Schedule")
    full = df[["time_label", "thermal_opt", "target", "net_demand", "solar", "wind", "ramp_mw_min"]].copy()
    full.columns = ["Time", "Opt Dispatch (MW)", "Target (MW)", "Net Demand (MW)", "Solar (MW)", "Wind (MW)", "Ramp (MW/min)"]
    for c in full.columns[1:]:
        full[c] = full[c].round(1)
    st.dataframe(full, use_container_width=True, hide_index=True, height=500)

# Status bar
st.markdown(
    f"""
    <div class="status-bar">
        <span>
            <span class="status-ok">● Live</span>
            &nbsp;&nbsp;Last optimised: {datetime.now().strftime("%H:%M IST")}
            &nbsp;|&nbsp; Solver: HiGHS
            &nbsp;|&nbsp; Model confidence: {kpis['confidence']}%
            &nbsp;|&nbsp; Data freshness: &lt; 2 min
        </span>
        <span>
            NASA C-MAPSS health: <span class="status-ok">{kpis['cmapss_health']}%</span>
            &nbsp;|&nbsp; ThermalFlex AI · SIH 2026 · NextGen-Grid
        </span>
    </div>
    """,
    unsafe_allow_html=True,
)
