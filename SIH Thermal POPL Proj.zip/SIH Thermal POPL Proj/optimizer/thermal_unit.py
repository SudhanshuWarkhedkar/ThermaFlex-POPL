"""
Thermal Power Plant Technical Specifications & Operating Constraints.
Encapsulates unit rated capacity, Minimum Technical Loading (MTL), ramp rate limits,
heat rate degradation curves, and startup/shutdown characteristics under CERC/CEA rules.
"""

from typing import Dict, Any

class ThermalUnit:
    """Represents an individual coal/gas thermal generating unit with physical constraints."""

    def __init__(
        self,
        name: str = "Unit 1 (Supercritical)",
        p_max_mw: float = 660.0,
        mtl_pct: float = 55.0,
        max_ramp_rate_mw_min: float = 18.0,
        current_load_mw: float = None,
        base_heat_rate_kcal_kwh: float = 2150.0
    ):
        self.name = name
        self.p_max = float(p_max_mw)
        self.mtl_pct = float(mtl_pct)
        self.p_mtl = round((self.mtl_pct / 100.0) * self.p_max, 2)
        self.max_ramp_rate_mw_min = float(max_ramp_rate_mw_min)
        self.current_load_mw = float(current_load_mw) if current_load_mw is not None else float(self.p_max * 0.85)
        self.base_heat_rate = float(base_heat_rate_kcal_kwh)

    def get_heat_rate_penalty_pct(self, load_mw: float) -> float:
        """
        Computes heat rate degradation percentage as a function of loading factor.
        Under CERC norms, heat rate degrades non-linearly below 70% loading.
        """
        loading_factor = load_mw / self.p_max
        if loading_factor >= 0.85:
            return 0.0
        elif loading_factor >= 0.70:
            return round((0.85 - loading_factor) * 8.0, 2)
        elif loading_factor >= 0.55:
            return round(1.2 + (0.70 - loading_factor) * 25.0, 2)
        else:
            # Deep flex operation down to 40% MTL
            return round(4.95 + (0.55 - loading_factor) * 35.0, 2)

    def get_max_15min_ramp_mw(self) -> float:
        """Maximum allowable MW load change across a 15-minute dispatch time block."""
        return round(self.max_ramp_rate_mw_min * 15.0, 2)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "p_max_mw": self.p_max,
            "mtl_pct": self.mtl_pct,
            "p_mtl_mw": self.p_mtl,
            "max_ramp_rate_mw_min": self.max_ramp_rate_mw_min,
            "max_15min_ramp_mw": self.get_max_15min_ramp_mw(),
            "current_load_mw": self.current_load_mw,
            "base_heat_rate_kcal_kwh": self.base_heat_rate
        }
