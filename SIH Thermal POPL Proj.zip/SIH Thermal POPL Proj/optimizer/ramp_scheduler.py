"""
Linear Programming Ramp Optimization Engine.
Solves constrained flexible ramping dispatch using high-performance HiGHS solver in scipy.optimize.
Guarantees strict compliance with Minimum Technical Load (55% MTL) and maximum ramp rate limits (MW/min).
"""

import time
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from scipy.optimize import linprog
from optimizer.thermal_unit import ThermalUnit

class RampScheduler:
    """Optimizes thermal plant dispatch trajectory subject to technical ramping limits."""

    def __init__(self, unit: ThermalUnit):
        self.unit = unit

    def optimize_schedule(
        self,
        p_target_mw: np.ndarray,
        lambda_ramp: float = 0.25,
        lambda_heat: float = 0.05
    ) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Solves the LP:
          min sum(s_t+ + s_t-) + lambda_ramp * sum(r_t+ + r_t-) + lambda_heat * sum(P_max - P_t)
          s.t.
            P_t - s_t+ + s_t- = P_target[t]
            P_t - P_{t-1} - r_t+ + r_t- = 0
            -R_max * dt <= P_t - P_{t-1} <= R_max * dt
            P_MTL <= P_t <= P_max
        """
        start_time = time.time()
        T = len(p_target_mw)
        dt_mins = 15.0
        max_step_ramp = self.unit.max_ramp_rate_mw_min * dt_mins
        p_mtl = self.unit.p_mtl
        p_max = self.unit.p_max
        p_init = self.unit.current_load_mw

        # Decision variables:
        # 0 to T-1: P_t (T)
        # T to 2T-1: s_t+ (T)
        # 2T to 3T-1: s_t- (T)
        # 3T to 4T-1: r_t+ (T)
        # 4T to 5T-1: r_t- (T)
        n_vars = 5 * T

        # Objective vector c
        c = np.zeros(n_vars)
        # Tracking slacks
        c[T:2*T] = 1.0
        c[2*T:3*T] = 1.0
        # Ramp penalty slacks (thermal stress reduction)
        c[3*T:4*T] = lambda_ramp
        c[4*T:5*T] = lambda_ramp
        # Heat rate penalty (incentivize operating closer to optimal load when possible)
        c[0:T] = -lambda_heat  # minimizing -(lambda_heat * P_t) is maximizing P_t slightly

        # Equality Constraints:
        # 1. Tracking: P_t - s_t+ + s_t- = P_target[t] (T rows)
        # 2. Ramp diff: P_t - P_{t-1} - r_t+ + r_t- = 0 (T rows)
        A_eq = np.zeros((2 * T, n_vars))
        b_eq = np.zeros(2 * T)

        for t in range(T):
            # Tracking
            A_eq[t, t] = 1.0
            A_eq[t, T + t] = -1.0
            A_eq[t, 2 * T + t] = 1.0
            b_eq[t] = p_target_mw[t]

            # Ramp definition
            A_eq[T + t, t] = 1.0
            if t > 0:
                A_eq[T + t, t - 1] = -1.0
            A_eq[T + t, 3 * T + t] = -1.0
            A_eq[T + t, 4 * T + t] = 1.0
            b_eq[T + t] = p_init if t == 0 else 0.0

        # Inequality Constraints (Physical Ramp Rate limits):
        # 1. Ramp up: P_t - P_{t-1} <= max_step_ramp
        # 2. Ramp down: P_{t-1} - P_t <= max_step_ramp
        # 2 * T inequality rows
        A_ub = np.zeros((2 * T, n_vars))
        b_ub = np.zeros(2 * T)

        for t in range(T):
            # Ramp Up
            A_ub[2 * t, t] = 1.0
            if t > 0:
                A_ub[2 * t, t - 1] = -1.0
                b_ub[2 * t] = max_step_ramp
            else:
                b_ub[2 * t] = max_step_ramp + p_init

            # Ramp Down
            A_ub[2 * t + 1, t] = -1.0
            if t > 0:
                A_ub[2 * t + 1, t - 1] = 1.0
                b_ub[2 * t + 1] = max_step_ramp
            else:
                b_ub[2 * t + 1] = max_step_ramp - p_init

        # Bounds: P_t in [P_MTL, P_max], all slacks >= 0
        bounds = [(p_mtl, p_max)] * T + [(0.0, None)] * (4 * T)

        # Solve via HiGHS
        res = linprog(
            c,
            A_ub=A_ub,
            b_ub=b_ub,
            A_eq=A_eq,
            b_eq=b_eq,
            bounds=bounds,
            method="highs"
        )

        solve_time_ms = round((time.time() - start_time) * 1000.0, 1)

        if not res.success:
            print(f"[RampScheduler] Optimization failed: {res.message}. Falling back to clipped projection.")
            p_opt = np.clip(p_target_mw, p_mtl, p_max)
        else:
            p_opt = res.x[:T]

        # Calculate step ramps
        prev_p = np.insert(p_opt[:-1], 0, p_init)
        ramps_mw = p_opt - prev_p
        ramp_rates_mw_min = ramps_mw / dt_mins

        # Direction classification
        directions = []
        for r in ramp_rates_mw_min:
            if r > 0.15:
                directions.append("RAMP UP")
            elif r < -0.15:
                directions.append("RAMP DOWN")
            else:
                directions.append("HOLD / STEADY")

        # Headroom and Reserve
        headroom_down = np.maximum(0.0, p_opt - p_mtl)
        spinning_reserve_up = np.maximum(0.0, p_max - p_opt)

        # Heat rate penalties
        heat_rate_penalties = [self.unit.get_heat_rate_penalty_pct(p) for p in p_opt]

        # Build 96-block Schedule DataFrame
        time_labels = [f"{b * 15 // 60:02d}:{(b * 15) % 60:02d}" for b in range(T)]
        df_schedule = pd.DataFrame({
            "block_id": np.arange(1, T + 1),
            "time": time_labels,
            "target_mw": np.round(p_target_mw, 1),
            "optimized_mw": np.round(p_opt, 1),
            "ramp_rate_mw_min": np.round(ramp_rates_mw_min, 2),
            "ramp_direction": directions,
            "headroom_to_mtl_mw": np.round(headroom_down, 1),
            "spinning_reserve_mw": np.round(spinning_reserve_up, 1),
            "heat_rate_penalty_pct": heat_rate_penalties
        })

        max_ramp_seen = float(np.max(np.abs(ramp_rates_mw_min)))
        tracking_mae = float(np.mean(np.abs(p_opt - p_target_mw)))
        total_gen_gwh = float(np.sum(p_opt) * 0.25 / 1000.0)

        metrics = {
            "status": "Optimal" if res.success else "Clipped Feasible",
            "solve_time_ms": solve_time_ms,
            "tracking_mae_mw": round(tracking_mae, 1),
            "max_ramp_rate_mw_min": round(max_ramp_seen, 2),
            "ramp_limit_mw_min": self.unit.max_ramp_rate_mw_min,
            "p_mtl_mw": p_mtl,
            "p_max_mw": p_max,
            "total_gen_gwh": round(total_gen_gwh, 2),
            "min_load_reached_mw": round(float(np.min(p_opt)), 1),
            "peak_load_reached_mw": round(float(np.max(p_opt)), 1)
        }

        return df_schedule, metrics
