"""
Operator Shift Advisory Generator.
Extracts distinct ramping maneuvers from the 96-block schedule:
  - Specific times to reduce load, by how much, and required MW/min
  - Specific times to hold at Minimum Technical Load (55% MTL)
  - Specific times to bring load back up, by how much, and required MW/min
  - Engineering operational instructions for boiler and turbine control rooms
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any

class AdvisoryGenerator:
    """Translates numerical dispatch schedules into actionable operational shift orders."""

    @staticmethod
    def generate_advisories(
        df_schedule: pd.DataFrame,
        unit_capacity_mw: float,
        mtl_mw: float,
        confidence_score: float
    ) -> List[Dict[str, Any]]:
        """
        Scans schedule blocks to segment the 3 primary operational phases:
          1. Morning Solar Ramp-Down Phase
          2. Midday Low-Load MTL Sustain Phase
          3. Evening Solar Sunset Rapid Ramp-Up Phase
        """
        T = len(df_schedule)
        opt = df_schedule["optimized_mw"].values
        times = df_schedule["time"].values
        ramps = df_schedule["ramp_rate_mw_min"].values

        # 1. Detect Morning Ramp Down Window (usually between 07:00 and 12:00, blocks 28 to 48)
        # Find where negative ramp rates are sustained
        down_blocks = [i for i in range(20, 52) if ramps[i] < -0.20]
        if down_blocks:
            start_down = down_blocks[0]
            end_down = down_blocks[-1]
            # expand slightly to capture full transition
            while start_down > 0 and ramps[start_down - 1] < -0.10:
                start_down -= 1
            while end_down < T - 1 and ramps[end_down + 1] < -0.10:
                end_down += 1

            start_down_mw = float(opt[start_down])
            end_down_mw = float(opt[end_down])
            mw_reduced = round(start_down_mw - end_down_mw, 1)
            duration_mins = (end_down - start_down + 1) * 15
            avg_rate = round(mw_reduced / duration_mins, 2) if duration_mins > 0 else 0.0
            peak_rate = round(float(np.min(ramps[start_down:end_down + 1])), 2)

            ramp_down_maneuver = {
                "phase": "PHASE 1: MORNING RAMP-DOWN (Solar Influx Absorption)",
                "action": "RAMP DOWN LOAD",
                "start_time": times[start_down],
                "end_time": times[end_down],
                "duration_str": f"{duration_mins} mins ({duration_mins // 60}h {duration_mins % 60}m)",
                "initial_mw": start_down_mw,
                "target_mw": end_down_mw,
                "delta_mw": -mw_reduced,
                "avg_ramp_rate_mw_min": -avg_rate,
                "peak_ramp_rate_mw_min": peak_rate,
                "engineering_instructions": [
                    "Back down boiler fuel firing in coordinate control mode (CCM).",
                    "Take out top elevation pulverizer mill C/D to preserve low-load flame envelope.",
                    "Tilt burner nozzles downward (-5° to -10°) to protect reheat steam temperatures.",
                    "Monitor deaerator pressure and condensate throttling margin."
                ],
                "severity": "info"
            }
        else:
            ramp_down_maneuver = {
                "phase": "PHASE 1: MORNING LOAD ADJUSTMENT",
                "action": "STEADY LOAD",
                "start_time": "08:00",
                "end_time": "11:30",
                "duration_str": "3h 30m",
                "initial_mw": float(opt[32]),
                "target_mw": float(opt[46]),
                "delta_mw": round(float(opt[46] - opt[32]), 1),
                "avg_ramp_rate_mw_min": -0.4,
                "peak_ramp_rate_mw_min": -0.6,
                "engineering_instructions": ["Maintain standard load tracking with automatic generation control (AGC)."],
                "severity": "info"
            }

        # 2. Midday Low-Load MTL Sustain Window (solar peak hours 11:30 to 15:30)
        # Find where load is close to MTL (within 10% of MTL)
        low_blocks = [i for i in range(36, 68) if opt[i] <= mtl_mw * 1.12]
        if low_blocks:
            start_hold = low_blocks[0]
            end_hold = low_blocks[-1]
            hold_duration_mins = (end_hold - start_hold + 1) * 15
            hold_avg_mw = round(float(np.mean(opt[start_hold:end_hold + 1])), 1)

            hold_maneuver = {
                "phase": "PHASE 2: MIDDAY FLEXIBLE MTL HOLD (Solar Peak Window)",
                "action": "HOLD AT MINIMUM TECHNICAL LOAD",
                "start_time": times[start_hold],
                "end_time": times[end_hold],
                "duration_str": f"{hold_duration_mins} mins ({hold_duration_mins // 60}h {hold_duration_mins % 60}m)",
                "initial_mw": hold_avg_mw,
                "target_mw": hold_avg_mw,
                "delta_mw": 0.0,
                "avg_ramp_rate_mw_min": 0.0,
                "peak_ramp_rate_mw_min": 0.0,
                "engineering_instructions": [
                    f"Maintain steady operation at ~{hold_avg_mw} MW (55% MTL minimum technical limit).",
                    "Verify flame scanner intensity across active bottom burner rows A & B.",
                    "Verify boiler feed pump (BFP) minimum flow recirculation valve is functional.",
                    "Standby for rapid ramp-up command prior to 16:00 solar decline."
                ],
                "severity": "warning"
            }
        else:
            hold_maneuver = {
                "phase": "PHASE 2: MIDDAY STEADY OPERATION",
                "action": "STEADY HOLD",
                "start_time": "12:00",
                "end_time": "15:30",
                "duration_str": "3h 30m",
                "initial_mw": float(opt[48]),
                "target_mw": float(opt[60]),
                "delta_mw": 0.0,
                "avg_ramp_rate_mw_min": 0.0,
                "peak_ramp_rate_mw_min": 0.0,
                "engineering_instructions": ["Sustain minimum safe baseload with secondary air dampers trimmed."],
                "severity": "info"
            }

        # 3. Detect Evening Ramp Up Window (solar sunset 15:45 to 20:30, blocks 63 to 82)
        up_blocks = [i for i in range(58, 86) if ramps[i] > 0.20]
        if up_blocks:
            start_up = up_blocks[0]
            end_up = up_blocks[-1]
            while start_up > 0 and ramps[start_up - 1] > 0.10:
                start_up -= 1
            while end_up < T - 1 and ramps[end_up + 1] > 0.10:
                end_up += 1

            start_up_mw = float(opt[start_up])
            end_up_mw = float(opt[end_up])
            mw_added = round(end_up_mw - start_up_mw, 1)
            up_duration_mins = (end_up - start_up + 1) * 15
            avg_up_rate = round(mw_added / up_duration_mins, 2) if up_duration_mins > 0 else 0.0
            peak_up_rate = round(float(np.max(ramps[start_up:end_up + 1])), 2)

            ramp_up_maneuver = {
                "phase": "PHASE 3: CRITICAL EVENING RAMP-UP (Duck Curve Neck Response)",
                "action": "RAMP UP LOAD TO FULL CAPACITY",
                "start_time": times[start_up],
                "end_time": times[end_up],
                "duration_str": f"{up_duration_mins} mins ({up_duration_mins // 60}h {up_duration_mins % 60}m)",
                "initial_mw": start_up_mw,
                "target_mw": end_up_mw,
                "delta_mw": +mw_added,
                "avg_ramp_rate_mw_min": +avg_up_rate,
                "peak_ramp_rate_mw_min": peak_up_rate,
                "engineering_instructions": [
                    "Initiate primary air fan boost and bring pulverizer mill C/D into service.",
                    "Engage condensate throttling for immediate 3-5% fast initial MW response.",
                    "Ramp boiler master fuel controller smoothly without exceeding steam separator thermal limits.",
                    "Ensure main steam and reheat steam temperatures stay within +/- 5°C of rated 565°C."
                ],
                "severity": "critical"
            }
        else:
            ramp_up_maneuver = {
                "phase": "PHASE 3: EVENING LOAD PICKUP",
                "action": "RAMP UP LOAD",
                "start_time": "16:30",
                "end_time": "19:45",
                "duration_str": "3h 15m",
                "initial_mw": float(opt[66]),
                "target_mw": float(opt[79]),
                "delta_mw": round(float(opt[79] - opt[66]), 1),
                "avg_ramp_rate_mw_min": +1.2,
                "peak_ramp_rate_mw_min": +1.6,
                "engineering_instructions": ["Bring additional mill into service to meet peak evening grid lighting demand."],
                "severity": "info"
            }

        return [ramp_down_maneuver, hold_maneuver, ramp_up_maneuver]
