"""Optimization and dispatch scheduling modules for thermal power plants."""
