@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title ThermalFlex AI  -  Control Room Dispatch Cockpit
color 0B

echo.
echo  ================================================================
echo   ThermalFlex AI - AI-Based Flexible Ramping Predictor
echo   Smart India Hackathon 2026  ^|  Team NextGen-Grid (RE04)
echo  ================================================================
echo.

if not exist "dashboard\app.py" (
    echo  [ERROR] dashboard\app.py was not found next to this file.
    echo          Put run_dashboard.bat and the dashboard folder in the same directory.
    echo.
    pause
    exit /b 1
)

set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY (
    where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo  [ERROR] Python was not found. Install Python 3.11+ and tick "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

echo  [INFO] Using: %PY%
%PY% -c "import streamlit, plotly, pandas, numpy" >nul 2>&1
if errorlevel 1 (
    echo  [INFO] Installing streamlit, plotly, pandas, numpy ...
    %PY% -m pip install streamlit plotly pandas numpy
    if errorlevel 1 (
        echo  [ERROR] Package install failed.
        pause
        exit /b 1
    )
)

echo  [INFO] Starting dashboard. Keep this window open.
echo.
%PY% -m streamlit run dashboard\app.py --server.port 8501 --browser.gatherUsageStats false
echo.
echo  Server stopped.
pause
endlocal