@echo off
title ThermalFlex AI - Ramping Predictor Dashboard
echo ======================================================================
echo Starting ThermalFlex AI - Flexible Ramping Predictor for Thermal Plants
echo Region Focus: Gujarat, Rajasthan, Maharashtra
echo Weather Feed: Free Open-Meteo Live API + Historical ERA5 Reanalysis
echo Equipment Degradation: NASA C-MAPSS Turbofan Stress Engine
echo Grid Curtailment: CEA Installed Capacity & Steps 4.1-4.5 Analytics
echo ======================================================================
echo.

python -m streamlit run dashboard/app.py --server.port=8501 --server.headless=false

pause
