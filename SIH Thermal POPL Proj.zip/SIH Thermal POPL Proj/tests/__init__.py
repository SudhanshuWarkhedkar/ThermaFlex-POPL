"""Automated tests for thermal ramping predictor."""
