"""
Automated End-to-End Test Suite for the AI-Based Flexible Ramping Predictor.
Verifies all 6 components requested:
  1. Demand Forecasting
  2. Renewable Generation
  3. NASA C-MAPSS Predictive Maintenance / Equipment Health
  4. Grid-wide Curtailment (Steps 4.1 to 4.5)
  5. Free Weather Client
  6. CEA 2024 Capacities for Gujarat, Rajasthan, and Maharashtra
  7. Constrained LP Ramping Optimizer & Advisories
"""

import unittest
import numpy as np
import pandas as pd

from data.cea_capacity import STATE_CAPACITIES, get_state_capacity
from data.weather_client import WeatherClient
from data.grid_loader import GridDataLoader
from data.curtailment_engine import CurtailmentEngine
from models.equipment_health import EquipmentHealthModel
from models.demand_forecaster import DemandForecaster
from models.re_forecaster import RenewableForecaster
from models.net_demand import NetDemandEngine
from models.confidence_engine import ConfidenceEngine
from optimizer.thermal_unit import ThermalUnit
from optimizer.ramp_scheduler import RampScheduler
from optimizer.advisory_generator import AdvisoryGenerator
from dashboard.scenarios import ScenarioSimulator

class TestThermalRampingPredictor(unittest.TestCase):
    """Unit and Integration Tests for Thermal Ramping Predictor System."""

    @classmethod
    def setUpClass(cls):
        cls.weather_client = WeatherClient()
        cls.grid_loader = GridDataLoader()
        cls.equipment_model = EquipmentHealthModel()
        cls.demand_forecaster = DemandForecaster(cls.grid_loader)
        cls.re_forecaster = RenewableForecaster()
        cls.curtailment_engine = CurtailmentEngine(cls.grid_loader)

    def test_cea_capacities_top_three_states(self):
        """Checks CEA 2024 installed capacity numbers for Gujarat, Rajasthan, and Maharashtra."""
        for state in ["Gujarat", "Rajasthan", "Maharashtra"]:
            cap = get_state_capacity(state)
            self.assertIn("solar_mw", cap)
            self.assertIn("wind_mw", cap)
            self.assertGreater(cap["solar_mw"], 1000.0)
            self.assertGreater(cap["wind_mw"], 1000.0)
            self.assertGreater(cap["total_mw"], 30000.0)

    def test_weather_client_fetching(self):
        """Verifies weather client returns valid 48-hour forecast with required columns."""
        df_w = self.weather_client.fetch_forecast("Gujarat", days=2)
        self.assertFalse(df_w.empty)
        required_cols = ["timestamp", "temperature_c", "cloud_cover_pct", "solar_irradiance_wm2", "wind_speed_ms"]
        for col in required_cols:
            self.assertIn(col, df_w.columns)
        self.assertGreaterEqual(len(df_w), 24)

    def test_curtailment_steps_4_1_to_4_5(self):
        """Verifies Steps 4.1 to 4.5 curtailment calculation on REIndia.csv."""
        df_curt = self.curtailment_engine.calculate_historical_curtailment("Gujarat")
        self.assertFalse(df_curt.empty)
        # Check step columns
        self.assertIn("Potential_Solar_MWh", df_curt.columns)
        self.assertIn("Curtailment_Solar_MWh", df_curt.columns)
        self.assertIn("Curtailment_Solar_Pct", df_curt.columns)
        self.assertIn("Solar_Sanity_1to5Pct", df_curt.columns)

        # Sanity check ranges
        mean_solar_curt = df_curt["Curtailment_Solar_Pct"].mean()
        self.assertGreaterEqual(mean_solar_curt, 0.0)
        self.assertLessEqual(mean_solar_curt, 15.0)

        # Check hourly risk cross-validation
        t = np.linspace(0, 24, 96)
        dummy_demand = 12000.0 * np.ones(96)
        dummy_solar = 8000.0 * np.sin(np.pi * np.clip(t - 6, 0, 12) / 12)
        dummy_wind = 2000.0 * np.ones(96)
        risk = self.curtailment_engine.evaluate_hourly_curtailment_risk(
            dummy_demand, dummy_solar, dummy_wind, thermal_fleet_mtl_mw=5000.0
        )
        self.assertIn("has_curtailment_risk", risk)

    def test_nasa_cmapss_equipment_health(self):
        """Verifies NASA C-MAPSS degradation model loads and evaluates ramping stress."""
        # Create test dispatch trajectory
        p_max = 660.0
        p_mtl = 363.0  # 55% MTL
        dispatch = np.linspace(p_max, p_mtl, 96)
        eval_result = self.equipment_model.evaluate_ramping_stress(
            dispatch, p_max, p_mtl, ramp_limits_mw_min=18.0
        )
        self.assertIn("component_health_pct", eval_result)
        self.assertIn("mean_stress_multiplier", eval_result)
        self.assertIn("estimated_rul_cycles", eval_result)
        self.assertGreaterEqual(eval_result["component_health_pct"], 70.0)
        self.assertLessEqual(eval_result["component_health_pct"], 100.0)

    def test_demand_and_re_forecasting(self):
        """Verifies demand and RE models generate 96-block 24-hour profiles."""
        weather_df = self.weather_client.fetch_forecast("Rajasthan", days=2)
        demand_96, d_metrics = self.demand_forecaster.predict_24h_profile("Rajasthan", weather_df)
        self.assertEqual(len(demand_96), 96)
        self.assertGreater(d_metrics["predicted_peak_mw"], 5000.0)

        solar_96, wind_96, re_96, re_metrics = self.re_forecaster.forecast_renewables("Rajasthan", weather_df)
        self.assertEqual(len(solar_96), 96)
        self.assertEqual(len(wind_96), 96)
        self.assertGreater(np.max(solar_96), 0.0)

    def test_optimizer_strict_constraints(self):
        """
        CRITICAL TEST: Verifies that optimizer NEVER violates:
          1. Minimum Technical Load (P_t >= P_MTL)
          2. Rated Capacity (P_t <= P_max)
          3. Ramp Rate Limit (|P_t - P_{t-1}| / 15 <= max_ramp_rate)
        """
        p_max = 500.0
        mtl_pct = 55.0
        p_mtl = (mtl_pct / 100.0) * p_max  # 275 MW
        max_ramp = 15.0  # MW/min

        unit = ThermalUnit(
            p_max_mw=p_max,
            mtl_pct=mtl_pct,
            max_ramp_rate_mw_min=max_ramp,
            current_load_mw=450.0
        )
        scheduler = RampScheduler(unit)

        # Severe duck curve target requesting steep violation
        p_target = np.array([450.0] * 30 + [150.0] * 30 + [550.0] * 36)  # Targets 150 < MTL and 550 > Pmax!
        df_sched, metrics = scheduler.optimize_schedule(p_target)

        opt_power = df_sched["optimized_mw"].values
        dt_mins = 15.0
        ramp_rates = np.abs(np.diff(opt_power)) / dt_mins

        # 1. MTL condition: No power strictly below MTL
        self.assertTrue(np.all(opt_power >= p_mtl - 1e-4), f"MTL violated! Min observed: {np.min(opt_power)}")

        # 2. Pmax condition: No power strictly above Pmax
        self.assertTrue(np.all(opt_power <= p_max + 1e-4), f"Pmax violated! Max observed: {np.max(opt_power)}")

        # 3. Ramp rate condition: No ramp strictly above max_ramp
        self.assertTrue(np.all(ramp_rates <= max_ramp + 1e-4), f"Ramp rate violated! Max ramp observed: {np.max(ramp_rates)}")

    def test_advisories_generation(self):
        """Verifies advisory generator extracts the 3 core shift maneuvers."""
        p_max = 660.0
        p_mtl = 363.0
        unit = ThermalUnit(p_max_mw=p_max, mtl_pct=55.0, max_ramp_rate_mw_min=18.0, current_load_mw=580.0)
        scheduler = RampScheduler(unit)

        t = np.linspace(0, 24, 96, endpoint=False)
        # Simulate realistic daily curve: high at night, drops at noon, peaks evening
        sim_target = p_mtl + (p_max - p_mtl) * (0.8 - 0.7 * np.exp(-((t - 13.0) ** 2) / 8.0))
        df_sched, _ = scheduler.optimize_schedule(sim_target)

        advisories = AdvisoryGenerator.generate_advisories(df_sched, p_max, p_mtl, confidence_score=92.0)
        self.assertEqual(len(advisories), 3)
        self.assertIn("RAMP DOWN", advisories[0]["action"])
        self.assertIn("HOLD", advisories[1]["action"])
        self.assertIn("RAMP UP", advisories[2]["action"])

    def test_top_three_states_cea_capacities(self):
        """Verifies top 3 target states (Gujarat, Rajasthan, Maharashtra) have valid CEA 2024 profiles."""
        from data.cea_capacity import get_all_states, TOP_3_STATES
        states = get_all_states()
        self.assertEqual(len(states), 3)
        self.assertEqual(set(states), {"Gujarat", "Rajasthan", "Maharashtra"})
        for s in states:
            cap = get_state_capacity(s)
            self.assertIn("solar_mw", cap)
            self.assertIn("wind_mw", cap)
            self.assertIn("thermal_coal_mw", cap)
            self.assertIn("coordinates", cap)
            self.assertIn("region", cap)
            self.assertGreaterEqual(cap["coordinates"]["lat"], 18.0)
            self.assertLessEqual(cap["coordinates"]["lat"], 30.0)

    def test_curtailment_map_engine_and_rules(self):
        """Verifies top 3 states curtailment simulation and diagnostic rules engine."""
        from data.curtailment_map_engine import CurtailmentMapEngine
        cme = CurtailmentMapEngine(self.grid_loader)
        df_telemetry = cme.get_live_map_telemetry(sim_hour=12.5, transmission_stress_factor=1.1, thermal_flex_enabled=False)
        self.assertFalse(df_telemetry.empty)
        self.assertEqual(len(df_telemetry), 3)
        self.assertEqual(set(df_telemetry["state"]), {"Gujarat", "Rajasthan", "Maharashtra"})

        required_cols = ["state", "curtailed_mw", "curtailment_pct", "primary_cause", "diagnostic_detail", "severity", "financial_loss_cr"]
        for c in required_cols:
            self.assertIn(c, df_telemetry.columns)

        # High curtailment state check
        rj = df_telemetry[df_telemetry["state"] == "Rajasthan"].iloc[0]
        self.assertGreater(rj["curtailed_mw"], 0.0)
        self.assertIn("Transmission Bottleneck", rj["primary_cause"])

        # Test national summary for top 3 states
        summary = cme.get_national_summary(df_telemetry)
        self.assertGreater(summary["total_curtailed_mw"], 1000.0)
        self.assertGreater(summary["total_financial_loss_cr"], 0.0)

        # Test effect of thermal flexibility (40% MTL retrofit)
        df_flex = cme.get_live_map_telemetry(sim_hour=12.5, transmission_stress_factor=1.1, thermal_flex_enabled=True)
        summary_flex = cme.get_national_summary(df_flex)
        self.assertLessEqual(summary_flex["total_curtailed_mw"], summary["total_curtailed_mw"])

    def test_turbine_predictive_maintenance_dual_models(self):
        """Verifies NASA C-MAPSS feature engineering and dual XGBoost models (RUL + Risk %)."""
        from models.turbine_predictive_maintenance import TurbinePredictiveMaintenance, PLANT_FLEET_COMPONENTS
        tpm = TurbinePredictiveMaintenance()
        self.assertTrue(tpm.is_trained)
        self.assertIn("rul_mae_cycles", tpm.test_metrics)
        self.assertLess(tpm.test_metrics["rul_mae_cycles"], 20.0)
        self.assertGreaterEqual(tpm.test_metrics["classification_accuracy"], 85.0)

        # Test single component prediction
        res = tpm.predict_component_telemetry("Unit 1: HP Turbine Rotor", cycle_step=15)
        self.assertIn("predicted_rul_cycles", res)
        self.assertIn("failure_risk_pct", res)
        self.assertIn("health_score_pct", res)
        self.assertIn("sensor_readings", res)
        self.assertGreaterEqual(res["failure_risk_pct"], 0.0)
        self.assertLessEqual(res["failure_risk_pct"], 100.0)

        # Test ranked fleet list
        df_ranked = tpm.get_fleet_ranked_criticality()
        self.assertEqual(len(df_ranked), len(PLANT_FLEET_COMPONENTS))
        self.assertIn("Failure Risk", df_ranked.columns)
        self.assertIn("RUL (Cycles)", df_ranked.columns)

    def test_live_streaming_telemetry(self):
        """Verifies live streaming row-by-row stepping simulates degrading sensors."""
        from models.turbine_predictive_maintenance import TurbinePredictiveMaintenance
        tpm = TurbinePredictiveMaintenance()
        # Compare early cycle vs late cycle near end-of-life
        early_res = tpm.predict_component_telemetry("Unit 1: HP Turbine Rotor", cycle_step=10)
        late_res = tpm.predict_component_telemetry("Unit 1: HP Turbine Rotor", cycle_step=200)

        # Failure risk should be higher in late life
        self.assertGreater(late_res["failure_risk_pct"], early_res["failure_risk_pct"])
        # RUL should be lower in late life
        self.assertLess(late_res["predicted_rul_cycles"], early_res["predicted_rul_cycles"])
        # Late life should trigger critical alert
        self.assertEqual(late_res["alert_level"], "CRITICAL")

if __name__ == "__main__":
    unittest.main()
