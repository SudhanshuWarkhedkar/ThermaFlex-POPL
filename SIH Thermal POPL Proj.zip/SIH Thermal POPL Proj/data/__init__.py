"""Data processing and external feeds for Thermal Ramping Predictor."""
