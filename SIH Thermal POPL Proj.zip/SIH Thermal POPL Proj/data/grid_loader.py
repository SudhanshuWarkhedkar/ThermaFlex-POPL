"""
Grid-India & CEA Data Loader.
Loads historical demand (2014-2024), daily energy met, and CEA renewable generation datasets.
Synthesizes standardized 96-block (15-minute) dispatch intervals.
"""

import os
import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple, Optional

class GridDataLoader:
    """Manages ingestion of historical electricity demand and renewable generation datasets."""

    def __init__(self, base_dir: Optional[str] = None):
        if base_dir is None:
            self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        else:
            self.base_dir = base_dir

        self.demand_dir = os.path.join(self.base_dir, "Demand Forecasting")
        self.re_dir = os.path.join(self.base_dir, "Renewable Generation")

    def load_historical_peak(self, state: str) -> pd.DataFrame:
        """Loads daily peak demand in MW for the given state (2013-2024)."""
        peak_path = os.path.join(self.demand_dir, "corrected_peak_met_MW.csv")
        df = pd.read_csv(peak_path)
        df["Date"] = pd.to_datetime(df["Date"])
        
        # Look for state column
        matching_col = None
        for col in df.columns:
            if col.strip().lower() == state.strip().lower():
                matching_col = col
                break
        
        if matching_col is None:
            raise ValueError(f"State {state} not found in peak demand columns: {df.columns.tolist()}")

        sub_df = df[["Date", matching_col]].rename(columns={matching_col: "peak_met_mw"}).dropna()
        sub_df["state"] = state
        return sub_df

    def load_historical_energy(self, state: str) -> pd.DataFrame:
        """Loads daily energy met in Million Units (MU) for the given state (2013-2024)."""
        energy_path = os.path.join(self.demand_dir, "corrected_daily_energy_met_MU.csv")
        df = pd.read_csv(energy_path)
        df["Date"] = pd.to_datetime(df["Date"])

        matching_col = None
        for col in df.columns:
            if col.strip().lower() == state.strip().lower():
                matching_col = col
                break

        if matching_col is None:
            raise ValueError(f"State {state} not found in energy met columns: {df.columns.tolist()}")

        sub_df = df[["Date", matching_col]].rename(columns={matching_col: "daily_energy_mu"}).dropna()
        sub_df["state"] = state
        return sub_df

    def load_re_generation(self, state: str) -> pd.DataFrame:
        """
        Loads CEA monthly renewable generation from REIndia.csv for the specified state.
        Returns Solar and Wind generation in MUs and MWh.
        """
        re_path = os.path.join(self.re_dir, "REIndia.csv")
        df = pd.read_csv(re_path)
        # Strip column names
        df.columns = [c.strip() for c in df.columns]
        df["State"] = df["State"].astype(str).str.strip()

        sub_df = df[df["State"].str.lower() == state.strip().lower()].copy()
        if sub_df.empty:
            raise ValueError(f"State '{state}' not found in REIndia.csv. States: {df['State'].unique().tolist()}")

        # Convert Solar and Wind to numeric
        for col in ["Wind", "Solar", "Biomass", "Bagasse", "Small Hydel", "Total"]:
            if col in sub_df.columns:
                sub_df[col] = pd.to_numeric(sub_df[col], errors="coerce").fillna(0.0)

        # Convert MUs to MWh (1 MU = 1000 MWh)
        sub_df["Solar_MWh"] = sub_df["Solar"] * 1000.0
        sub_df["Wind_MWh"] = sub_df["Wind"] * 1000.0
        sub_df["Total_RE_MWh"] = sub_df["Total"] * 1000.0

        return sub_df

    def load_combined_training_data(self, state: str) -> pd.DataFrame:
        """
        Merges daily weather variables (ERA5) with peak demand and energy met for ML model training.
        """
        from data.cea_capacity import get_state_capacity
        cap = get_state_capacity(state)
        weather_path = os.path.join(self.demand_dir, cap["csv_name"])

        df_w = pd.read_csv(weather_path)
        df_w["date"] = pd.to_datetime(df_w["date"])

        df_peak = self.load_historical_peak(state)
        df_energy = self.load_historical_energy(state)

        merged = pd.merge(df_w, df_peak, left_on="date", right_on="Date", how="inner")
        merged = pd.merge(merged, df_energy[["Date", "daily_energy_mu"]], on="Date", how="inner")

        merged = merged.drop(columns=["Date"]).dropna()
        return merged

    @staticmethod
    def get_diurnal_demand_shape(state: str) -> np.ndarray:
        """
        Returns normalized 96-block (15-min) load shape curve for Indian state grid.
        Peak at morning (08:30-10:30), afternoon industrial dip (13:00),
        and highest evening peak (19:30-22:00) characteristic of Indian grid load curve.
        """
        t = np.linspace(0, 24, 96, endpoint=False)
        # Diurnal multi-harmonic fit for Indian state demand (Gujarat/Rajasthan/Maharashtra)
        # Base load = 0.72
        base = 0.72
        morning_peak = 0.18 * np.exp(-((t - 9.5) ** 2) / (2 * 1.8 ** 2))
        afternoon_dip = -0.06 * np.exp(-((t - 13.5) ** 2) / (2 * 1.5 ** 2))
        evening_peak = 0.28 * np.exp(-((t - 20.0) ** 2) / (2 * 2.2 ** 2))
        night_trough = -0.12 * np.exp(-((t - 3.5) ** 2) / (2 * 2.0 ** 2))

        # Slight state customization
        if state.lower() == "rajasthan":
            # Higher agricultural morning load
            morning_peak *= 1.15
        elif state.lower() == "gujarat":
            # Higher continuous industrial baseload
            base = 0.76
        elif state.lower() == "maharashtra":
            # High Mumbai commercial/residential evening cooling peak
            evening_peak *= 1.20

        shape = base + morning_peak + afternoon_dip + evening_peak + night_trough
        # Normalize so that max is 1.0
        return shape / np.max(shape)
