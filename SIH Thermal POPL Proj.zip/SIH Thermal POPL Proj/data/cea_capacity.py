"""
Central Electricity Authority (CEA) Installed Capacity Records (2024).
Provides state-wise generation mix and coordinates for Gujarat, Rajasthan, and Maharashtra.
"""

from typing import Dict, Any

STATE_CAPACITIES: Dict[str, Dict[str, Any]] = {
    # --- Western Region (WR) ---
    "Gujarat": {
        "solar_mw": 11250.0,
        "wind_mw": 11400.0,
        "thermal_coal_mw": 15200.0,
        "thermal_gas_mw": 6200.0,
        "hydro_mw": 1990.0,
        "nuclear_mw": 1140.0,
        "total_mw": 48500.0,
        "default_cuf": {"solar": 0.21, "wind": 0.28},
        "coordinates": {"lat": 23.2156, "lon": 72.6369},  # Gandhinagar
        "region": "WR",
        "csv_name": "Gujarat.csv",
        "weather_station": "Ahmedabad / Charanka Solar Park",
        "corridors": ["WR-NR", "WR-SR"]
    },
    "Maharashtra": {
        "solar_mw": 5450.0,
        "wind_mw": 5250.0,
        "thermal_coal_mw": 24800.0,
        "thermal_gas_mw": 3500.0,
        "hydro_mw": 3350.0,
        "nuclear_mw": 1400.0,
        "total_mw": 45800.0,
        "default_cuf": {"solar": 0.20, "wind": 0.26},
        "coordinates": {"lat": 19.0760, "lon": 72.8777},  # Mumbai
        "region": "WR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Nagpur / Chandrapur Thermal Belt",
        "corridors": ["WR-SR", "WR-ER"]
    },
    "Madhya Pradesh": {
        "solar_mw": 3400.0,  # Rewa Ultra Mega Solar Park
        "wind_mw": 2850.0,
        "thermal_coal_mw": 14900.0,
        "thermal_gas_mw": 300.0,
        "hydro_mw": 3220.0,
        "nuclear_mw": 0.0,
        "total_mw": 25200.0,
        "default_cuf": {"solar": 0.22, "wind": 0.23},
        "coordinates": {"lat": 23.2599, "lon": 77.4126},  # Bhopal / Rewa
        "region": "WR",
        "csv_name": "Gujarat.csv",
        "weather_station": "Rewa / Singrauli",
        "corridors": ["WR-NR", "WR-ER"]
    },
    "Chhattisgarh": {
        "solar_mw": 980.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 21800.0,  # Massive coal thermal hub (Korba)
        "thermal_gas_mw": 0.0,
        "hydro_mw": 120.0,
        "nuclear_mw": 0.0,
        "total_mw": 23100.0,
        "default_cuf": {"solar": 0.19, "wind": 0.18},
        "coordinates": {"lat": 21.2514, "lon": 81.6296},  # Raipur / Korba
        "region": "WR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Korba Coal Belt",
        "corridors": ["WR-ER", "WR-SR"]
    },

    # --- Northern Region (NR) ---
    "Rajasthan": {
        "solar_mw": 19850.0,  # #1 in India (Bhadla, Fatehgarh)
        "wind_mw": 5200.0,
        "thermal_coal_mw": 9900.0,
        "thermal_gas_mw": 1020.0,
        "hydro_mw": 1920.0,
        "nuclear_mw": 1180.0,
        "total_mw": 41000.0,
        "default_cuf": {"solar": 0.24, "wind": 0.25},
        "coordinates": {"lat": 26.9124, "lon": 75.7873},  # Jaipur
        "region": "NR",
        "csv_name": "Rajasthan.csv",
        "weather_station": "Jodhpur / Bhadla Solar Park",
        "corridors": ["NR-WR", "NR-ER"]
    },
    "Punjab": {
        "solar_mw": 1250.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 5680.0,
        "thermal_gas_mw": 0.0,
        "hydro_mw": 3800.0,
        "nuclear_mw": 0.0,
        "total_mw": 14200.0,
        "default_cuf": {"solar": 0.19, "wind": 0.18},
        "coordinates": {"lat": 30.7333, "lon": 76.7794},  # Chandigarh
        "region": "NR",
        "csv_name": "Rajasthan.csv",
        "weather_station": "Patiala / Bhatinda",
        "corridors": ["NR-Inter"]
    },
    "Uttar Pradesh": {
        "solar_mw": 2650.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 23500.0,  # Anpara, Obra, Harduaganj
        "thermal_gas_mw": 550.0,
        "hydro_mw": 500.0,
        "nuclear_mw": 440.0,
        "total_mw": 30500.0,
        "default_cuf": {"solar": 0.19, "wind": 0.18},
        "coordinates": {"lat": 26.8467, "lon": 80.9462},  # Lucknow
        "region": "NR",
        "csv_name": "Rajasthan.csv",
        "weather_station": "Sonbhadra / Prayagraj",
        "corridors": ["NR-ER", "NR-WR"]
    },
    "Haryana": {
        "solar_mw": 1150.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 7100.0,
        "thermal_gas_mw": 430.0,
        "hydro_mw": 1900.0,
        "nuclear_mw": 0.0,
        "total_mw": 12800.0,
        "default_cuf": {"solar": 0.19, "wind": 0.18},
        "coordinates": {"lat": 29.0588, "lon": 76.0856},  # Rohtak
        "region": "NR",
        "csv_name": "Rajasthan.csv",
        "weather_station": "Panipat / Hisar",
        "corridors": ["NR-Inter"]
    },

    # --- Southern Region (SR) ---
    "Karnataka": {
        "solar_mw": 16400.0,  # #2 in India (Pavagada Ultra Mega Solar)
        "wind_mw": 6150.0,
        "thermal_coal_mw": 9800.0,  # Raichur, Bellary, Yermarus
        "thermal_gas_mw": 0.0,
        "hydro_mw": 3700.0,
        "nuclear_mw": 880.0,
        "total_mw": 37800.0,
        "default_cuf": {"solar": 0.22, "wind": 0.28},
        "coordinates": {"lat": 12.9716, "lon": 77.5946},  # Bengaluru / Pavagada
        "region": "SR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Tumkur / Pavagada Solar Park",
        "corridors": ["SR-WR", "SR-ER"]
    },
    "Tamil Nadu": {
        "solar_mw": 7200.0,  # Kamuthi Solar
        "wind_mw": 10450.0,  # Muppandal wind corridor #1
        "thermal_coal_mw": 13600.0,  # North Chennai, Tuticorin, Mettur
        "thermal_gas_mw": 1020.0,
        "hydro_mw": 2180.0,
        "nuclear_mw": 2440.0,  # Kudankulam, Kalpakkam
        "total_mw": 38100.0,
        "default_cuf": {"solar": 0.21, "wind": 0.32},
        "coordinates": {"lat": 13.0827, "lon": 80.2707},  # Chennai
        "region": "SR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Tirunelveli / Muppandal",
        "corridors": ["SR-WR", "SR-ER"]
    },
    "Andhra Pradesh": {
        "solar_mw": 4550.0,  # Kurnool Ultra Solar
        "wind_mw": 4100.0,
        "thermal_coal_mw": 11800.0,  # Vijayawada, Krishnapatnam
        "thermal_gas_mw": 1000.0,
        "hydro_mw": 1800.0,
        "nuclear_mw": 0.0,
        "total_mw": 24800.0,
        "default_cuf": {"solar": 0.22, "wind": 0.27},
        "coordinates": {"lat": 15.8281, "lon": 78.0373},  # Kurnool
        "region": "SR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Kurnool Solar Park",
        "corridors": ["SR-WR", "SR-ER"]
    },
    "Telangana": {
        "solar_mw": 4700.0,
        "wind_mw": 130.0,
        "thermal_coal_mw": 9600.0,  # Ramagundam, Kothagudem
        "thermal_gas_mw": 0.0,
        "hydro_mw": 2400.0,
        "nuclear_mw": 0.0,
        "total_mw": 18200.0,
        "default_cuf": {"solar": 0.21, "wind": 0.22},
        "coordinates": {"lat": 17.3850, "lon": 78.4867},  # Hyderabad
        "region": "SR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Ramagundam",
        "corridors": ["SR-WR"]
    },
    "Kerala": {
        "solar_mw": 850.0,
        "wind_mw": 70.0,
        "thermal_coal_mw": 0.0,
        "thermal_gas_mw": 530.0,
        "hydro_mw": 1860.0,  # Idukki
        "nuclear_mw": 0.0,
        "total_mw": 3500.0,
        "default_cuf": {"solar": 0.19, "wind": 0.24},
        "coordinates": {"lat": 10.8505, "lon": 76.2711},  # Kochi
        "region": "SR",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Palakkad",
        "corridors": ["SR-Local"]
    },

    # --- Eastern Region (ER) ---
    "Odisha": {
        "solar_mw": 480.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 9500.0,  # Talcher, Ib Valley
        "thermal_gas_mw": 0.0,
        "hydro_mw": 2150.0,
        "nuclear_mw": 0.0,
        "total_mw": 12800.0,
        "default_cuf": {"solar": 0.18, "wind": 0.18},
        "coordinates": {"lat": 20.9517, "lon": 85.0985},  # Bhubaneswar
        "region": "ER",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Talcher",
        "corridors": ["ER-WR", "ER-SR"]
    },
    "West Bengal": {
        "solar_mw": 220.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 10200.0,  # Kolaghat, Bakreswar, Sagardighi
        "thermal_gas_mw": 100.0,
        "hydro_mw": 1400.0,
        "nuclear_mw": 0.0,
        "total_mw": 12400.0,
        "default_cuf": {"solar": 0.17, "wind": 0.16},
        "coordinates": {"lat": 22.9868, "lon": 87.8550},  # Kolkata
        "region": "ER",
        "csv_name": "Maharashtra.csv",
        "weather_station": "Kolkata / Durgapur",
        "corridors": ["ER-NR", "ER-WR"]
    },
    "Bihar": {
        "solar_mw": 190.0,
        "wind_mw": 0.0,
        "thermal_coal_mw": 7200.0,  # Barh, Kahalgaon, Nabi Nagar
        "thermal_gas_mw": 0.0,
        "hydro_mw": 0.0,
        "nuclear_mw": 0.0,
        "total_mw": 7500.0,
        "default_cuf": {"solar": 0.18, "wind": 0.16},
        "coordinates": {"lat": 25.0961, "lon": 85.3131},  # Patna
        "region": "ER",
        "csv_name": "Rajasthan.csv",
        "weather_station": "Patna / Barh",
        "corridors": ["ER-NR"]
    }
}

# Regional Transmission Interconnector Transfer Capabilities (MW)
REGIONAL_TRANSMISSION_CORRIDORS: Dict[str, Dict[str, Any]] = {
    "WR-NR": {"capacity_mw": 16500.0, "normal_loading_pct": 74.5, "contingency_limit_pct": 90.0},
    "WR-SR": {"capacity_mw": 14200.0, "normal_loading_pct": 82.0, "contingency_limit_pct": 92.0},
    "NR-ER": {"capacity_mw": 9800.0, "normal_loading_pct": 68.0, "contingency_limit_pct": 88.0},
    "SR-ER": {"capacity_mw": 8300.0, "normal_loading_pct": 62.5, "contingency_limit_pct": 88.0},
    "WR-ER": {"capacity_mw": 12500.0, "normal_loading_pct": 71.0, "contingency_limit_pct": 90.0}
}

NAME_ALIASES = {
    "tamilnadu": "Tamil Nadu",
    "up": "Uttar Pradesh",
    "mp": "Madhya Pradesh",
    "ap": "Andhra Pradesh",
    "wb": "West Bengal",
    "maharashtra ": "Maharashtra",
    "gujarat ": "Gujarat",
    "rajasthan ": "Rajasthan",
    "haryana ": "Haryana",
    "bihar ": "Bihar"
}

def get_state_capacity(state: str) -> Dict[str, Any]:
    """Retrieve installed capacity parameters for a given state with alias matching."""
    s_raw = state.strip().lower()
    if s_raw in NAME_ALIASES:
        clean_state = NAME_ALIASES[s_raw]
    else:
        # Title case matching
        clean_state = " ".join([w.capitalize() for w in s_raw.split()])

    if clean_state not in STATE_CAPACITIES:
        # Fuzzy match
        for st_name in STATE_CAPACITIES:
            if st_name.lower() in s_raw or s_raw in st_name.lower():
                return STATE_CAPACITIES[st_name]
        raise ValueError(f"State '{state}' not supported. Choose from {list(STATE_CAPACITIES.keys())}")
    return STATE_CAPACITIES[clean_state]

TOP_3_STATES = ["Gujarat", "Rajasthan", "Maharashtra"]

def get_all_states() -> list:
    """Returns list of the top 3 target states (Gujarat, Rajasthan, Maharashtra)."""
    return list(TOP_3_STATES)

def get_states_by_region(region: str) -> list:
    """Returns list of states in a given grid region (WR, NR)."""
    return [s for s in TOP_3_STATES if STATE_CAPACITIES[s].get("region") == region.upper()]
